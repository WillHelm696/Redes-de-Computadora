<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
		<meta http-equiv="Pragma" content="no-cache">
		<meta http-equiv="Expires" content="0">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Beneficios exclusivos Singular | Banco Patagonia</title>
		<meta name="description" content="Un cliente Singular tiene beneficios exclusivos.">
		<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NL73B44');</script>
<!-- End Google Tag Manager -->

<link rel="shortcut icon" href="../../favicon.ico" type="image/x-icon"/>
<link href="../../assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/mtabs/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/slick/slick.css" rel="stylesheet" type="text/css">
<link href="../../assets/js/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->        
        <!-- CSS (Patagonia Singular) -->
        <link href="../../assets/css/patagonia-singular.css" rel="stylesheet" type="text/css">
        
	</head>
<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NL73B44"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<div class="placeholder-bar">
	<div class="container-fluid header-bar">
		<div class="row">
			<header class="container">
				<div class="row">
					<div class="col-md-3 col-dsk-6 col-sm-6">
						<span class="c-hamburger c-hamburger--htx">
							<span>toggle menu</span>
						</span>
                        <!-- -->
                        <!--<img style="position: absolute; width: 42px; top: 20px; right: 40px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-verano-2022.svg">-->
                        <!-- -->
						<h1>
                            <!--<img style="position: absolute; width: 32px; top: 12px; left: 102px;" class="dsk" src="<php echo $path ?>assets/images/layout/icon-navidad-2021.svg">-->
                            <a href="../index.php" class="main-logo">Banco Patagonia</a>
                        </h1>
					</div>
					<div class="col-md-9 col-dsk-6 col-sm-6">
						<div class="general-links">
							<ul class="list-unstyled">
                                <li id="btn-hacete-cliente"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank"><strong>Hacete cliente <i class="fa fa-angle-right"></i></strong></a></li>								<li><a href="../../canales-de-atencion/index.php" class="">Canales de atención</a></li>
								<!--<li><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank">Sucursales y cajeros</a></li>-->
								<!--<li><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>">Contactanos</a></li>-->
                                <li><a href="../../ayuda/index.php" class="">Ayuda</a></li>
							</ul>
						</div>
						<div class="top-links">
							<ul class="list-unstyled">
								<li><a href="../index.php" class="active">PERSONAS</a></li>
								<li><a href="../../nyps/index.php" class="">NEGOCIOS Y PROFESIONALES</a></li>
								<li><a href="../../pyme/index.php" class="">PYME</a></li>
								<li><a href="../../agro/index.php" class="">AGRO</a></li>
								<li><a href="../../empresas/index.php" class="">EMPRESAS</a></li>
								<li><a href="../../sector-publico/index.php" class="">SECTOR PÚBLICO</a></li>
								<li><a href="../../institucional/index.php" class="">INSTITUCIONAL</a></li>
							</ul>
							<div class="ebank">
                            <!-- antes href: <php echo $folder_empresas ?><php echo $url_ebank ?>-->
															<a href="https://ebankpersonas.bancopatagonia.com.ar/eBanking/usuarios/login.htm" class="patagonia-ebank" target="_blank">Patagonia e-Bank</a>
														</div>
						</div>
					</div>
				</div>
			</header>
		</div>
	</div>
</div>

<div class="container-fluid nav-bar">
	<div class="row">
		<nav class="container">
			<div class="row">
				<!--<div class="col-md-9 col-md-offset-3">-->
                <div class="col-md-10 col-md-offset-3"><!-- ajuste agro -->
					<ul class="list-unstyled sub-navbar">
						
												<!-- PERSONAS -->
                        <li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA CLÁSICA</a>
							<ul class="list-unstyled submenu">
                                <!--<li><a href="../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>-->
                                <li><a href="../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                                <li><a href="../../personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>
                                <li><a href="../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                                <li><a href="../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA PLUS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                                <li><a href="../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
							</ul>						
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk active">PATAGONIA SINGULAR</a>
							<ul class="list-unstyled submenu">
								<li><a href="../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                                <li><a href="../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                                <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
							</ul>
						</li>
						<!--<li class="nav-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank" class="nav-lnk">PATAGONIA ON</a></li>-->
						<li class="nav-item"><a href="#" class="nav-lnk ">PATAGONIA ON</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
								<li><a href="../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
							</ul>
						</li>
						<li class="nav-item"><a href="#" class="nav-lnk ">PRODUCTOS Y SERVICIOS</a>
							<ul class="list-unstyled submenu">
                                <li><a href="../../personas/apple-pay.php">Apple Pay</a></li>
                                <li><a href="../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                                <li><a href="../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
								<li><a href="../../personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>
								<li><a href="../../personas/google-pay.php">Google Pay</a></li>
                                <li><a href="../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                                <li><a href="../../personas/productos-y-servicios/jubilados.php">Jubilados</a></li>
                                <li><a href="../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                                <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                                <li><a href="../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                                <li><a href="../../personas/productos-y-servicios/seguros.php">Seguros</a></li>
                                <li><a href="../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
								<li><a href="../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
							</ul>
						</li>
						<!-- FIN PERSONAS -->
						                        
                                                
                                                
                        						
												
												
						
											</ul>
				</div>
			</div>
		</nav>
	</div>
</div>

<div class="mobile-nav-bar">
	<ul class="list-unstyled">
        
        <!-- PERSONAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items active">PERSONAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../index.php" class="active">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <!--<li><a href="../../personas/patagonia-clasica/patagonia-ahorro/productos.php">Patagonia Ahorro</a></li>-->
                        <li><a href="../../personas/patagonia-clasica/paquete/productos.php">Patagonia Clásica</a></li>
                        <li><a href="../../personas/patagonia-clasica/mas/productos.php">Patagonia Clásica Más</a></li>
                        <li><a href="../../personas/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../personas/patagonia-clasica/patagonia-sueldo/productos.php">Patagonia Sueldo</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../personas/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu active">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../personas/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/atencion-exclusiva/index.php">Atención Exclusiva</a></li>-->
                        <!--<li><a href="<php echo $path ?>personas/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
				<!--<li class="nav-sub-item"><a href="<php echo $path ?>patagoniaon/index.php" target="_blank">PATAGONIA ON</a></li>-->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA ON</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../patagoniaon/index.php" target="_blank">Patagonia ON</a></li>
						<li><a href="../../personas/productos-y-servicios/patagonia-universitaria.php">Patagonia ON Universitaria</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../personas/apple-pay.php">Apple Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../personas/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
						<li><a href="../../personas/productos-y-servicios/beneficios-wapa.php">Comercios WAPA</a></li>
						<li><a href="../../personas/google-pay.php">Google Pay</a></li>
                        <li><a href="../../personas/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../personas/productos-y-servicios/jubilados.php">Jubilados</a></li>
                        <li><a href="../../personas/productos-y-servicios/patagonia-para-menores.php">Patagonia para Menores</a></li>
                        <!--<li><a href="<php echo $path ?>personas/productos-y-servicios/patagonia-universitaria.php">Patagonia Universitaria</a></li>-->
                        <li><a href="../../personas/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../personas/productos-y-servicios/seguros.php">Seguros</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../personas/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                    </ul>
                </li>
			</ul>
		</li>
        <!-- FIN PERSONAS -->
        
        <!-- NYPS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">NEGOCIOS Y PROFESIONALES <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../nyps/index.php" class="">HOME</a></li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA CLÁSICA</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-clasica/premium/productos.php">Patagonia Clásica Premium</a></li>
                        <li><a href="../../nyps/patagonia-clasica/patagonia-emprendimiento/productos.php">Patagonia Emprendimiento</a></li>
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA PLUS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-plus/productos.php">Patagonia Plus</a></li>
                        <li><a href="../../nyps/patagonia-plus/premium/productos.php">Patagonia Plus Premium</a></li>
                    </ul>						
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SINGULAR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/patagonia-singular/paquete/propuesta.php">Patagonia Singular</a></li>
                        <li><a href="../../nyps/patagonia-singular/beneficios-exclusivos.php">Beneficios Exclusivos</a></li>
                        <!--<li><a href="<php echo $path ?>nyps/patagonia-singular/eventos-y-novedades/index.php">Eventos y Novedades</a></li>-->
                    </ul>
                </li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">PRODUCTOS Y SERVICIOS</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-debito/patagonia-24.php">Tarjetas de débito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/tarjetas-de-credito/visa.php">Tarjetas de crédito</a></li>
                        <li><a href="../../nyps/productos-y-servicios/prestamos.php">Prestamos</a></li>
                        <li><a href="../../nyps/productos-y-servicios/seguros.php">Seguros</a></li>
                        <li><a href="../../nyps/productos-y-servicios/inversiones.php">Inversiones</a></li>
                        <li><a href="../../nyps/productos-y-servicios/comercio-exterior/productos.php">Comercio exterior</a></li>
                        <li><a href="../../nyps/productos-y-servicios/caja-de-seguridad.php">Caja de Seguridad</a></li>
                        <li><a href="../../nyps/productos-y-servicios/factura-electronica.php">Factura electrónica</a></li>
                        <li><a href="../../nyps/productos-y-servicios/pagos-afip.php">Pagos AFIP</a></li>
                        <li><a href="../../nyps/productos-y-servicios/soluciones-para-tu-empresa.php">Soluciones para tu empresa</a></li>
                        <li><a href="../../nyps/productos-y-servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
						<li><a href="../../nyps/productos-y-servicios/wapa.php">WAPA</a></li>
                    </ul>
                </li>
			</ul>		
		</li>
        <!-- FIN NYPS -->
        
        <!-- PYME -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">PYME <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../pyme/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">CUENTAS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../pyme/cuentas/pequenas-empresas.php">Pyme Pequeñas Empresas</a></li>
				        <li><a href="../../pyme/cuentas/medianas-empresas.php">Pyme Medianas Empresas</a></li>
                        <!--
						<li><a href="../../pyme/cuentas/patagonia-empresario.php">Patagonia Empresario</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresario-premier.php">Patagonia Empresario Premier</a></li>
						<li><a href="../../pyme/cuentas/patagonia-empresa.php">Patagonia Empresa</a></li>
                        -->
                        <li><a href="../../pyme/cuentas/patagonia-comercio.php">Patagonia Comercio</a></li>
                        <li><a href="../../pyme/cuentas/patagonia-consorcio.php">Patagonia Consorcio</a></li>
						<li><a href="../../pyme/cuentas/cuenta-corriente.php">Cuenta Corriente</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../pyme/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../pyme/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../pyme/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../pyme/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_pymeCexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../pyme/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../pyme/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../pyme/financiacion/mercado-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../pyme/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">SEGUROS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/seguros/protege-tus-bienes/integral-comercio.php">Protegé tus Bienes</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
						<li><a href="../../pyme/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../pyme/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
					</ul>
				</li>						
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../pyme/servicios/recaudaciones.php">Recaudaciones</a></li>
						<li><a href="../../pyme/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../pyme/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
						<li><a href="../../pyme/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>
                        <li><a href="../../pyme/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../pyme/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../pyme/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../pyme/servicios/pagos-afip.php">Pagos AFIP</a></li>
						<li><a href="../../pyme/servicios/wapa.php">WAPA</a></li>
					</ul>
				</li>
			</ul>		
		</li>
        <!-- FIN PYME -->
        
        <!-- AGRO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">AGRO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../agro/index.php" class="">HOME</a></li>
                <!-- -->
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">OFERTA AGRO</a>
					<ul class="list-unstyled submenu">
                    	<!--<li><a href="<php echo $folder_agroFinanciacion ?>insumos.php">Insumos en USD</a></li>-->
                        <li><a href="../../agro/convenios/acuerdos-y-beneficios.php">Acuerdos y convenios</a></li>
						<li><a href="../../agro/financiacion/maquinaria-agricola.php">Financiación Maquinaria Agrícola</a></li>
						<li><a href="../../agro/seguros/campo.php">Seguros para tu campo</a></li>
					</ul>
				</li>
                <!-- -->
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">TARJETA PATAGONIA AGRO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/tarjeta-patagonia-agro/para-usuarios.php">Para Usuarios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/para-comercios.php">Para Comercios</a></li>
						<li><a href="../../agro/tarjeta-patagonia-agro/acuerdo-tasa-0.php">Tarjetas Agro Convenios Preferenciales</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="../../agro/cuenta-agro/cuenta-agro.php" class="">CUENTA AGRO</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../agro/insumos/index.php">Insumos</a></li>
                        <li><a href="../../agro/financiacion/maquinaria-agricola.php">Maquinarias</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Camiones</a></li>
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>capital-de-trabajo.php">Capital de Trabajo</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>proyectos-de-inversion.php">Proyectos de Inversión</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>creditos-para-hacienda.php">Créditos para Hacienda</a></li>-->
						<!--<li><a href="<php echo $folder_agroFinanciacion ?>leasing-y-prendarios.php">Leasing y Prendarios</a></li>-->
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../agro/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../../agro/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
                <li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
                    <ul class="list-unstyled submenu">
                        <li><a href="../../agro/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
                        <li><a href="../../agro/comercio-exterior/productos.php">Productos</a></li>
                        <li><a href="../../agro/comercio-exterior/otros-servicios.php">Servicios</a></li>
                        <li><a href="../../agro/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
                        <li><a href="../../agro/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
                    </ul>
                </li>
                <!--
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../agro/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
                -->
                <!-- -->
                <li class="nav-sub-item"><a href="../../agro/seguros/campo.php" class="">SEGUROS</a></li>
                <!-- -->
			</ul>
		</li>
        <!-- FIN AGRO -->
        
        <!-- EMPRESAS -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">EMPRESAS <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../empresas/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PATAGONIA SUELDO</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/patagonia-sueldo/servicios.php">Servicios</a></li>
						<li><a href="../../empresas/patagonia-sueldo/preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
						<li><a href="../../empresas/patagonia-sueldo/guia-implementacion.php">Guía de Implementación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">COMERCIO EXTERIOR</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/comercio-exterior/solicitud-electronica.php">Solicitud Electrónica</a></li>
						<li><a href="../../empresas/comercio-exterior/productos.php">Productos</a></li>
						<li><a href="../../empresas/comercio-exterior/otros-servicios.php">Servicios</a></li>
						<!--<li><a href="<php echo $folder_Cexterior ?>financiaciones.php">Financiaciones</a></li>-->
                        <li><a href="../../empresas/comercio-exterior/herramientas-para-exportar.php">Herramientas para Exportar</a></li>
						<li><a href="../../empresas/comercio-exterior/marco-regulatorio/normas-y-regulaciones.php">Marco Regulatorio</a></li>
					</ul>
				</li>
                <!-- -->
				<!--<li class="nav-sub-item"><a href="../../empresas/comunidades-de-negocios/index.php" class="">COMUNIDADES DE NEGOCIOS</a></li>-->
                <!-- -->
				<li class="nav-sub-item"><a href="index.php" class="nav-lnk ">COMERCIOS PATAGONIA</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">FINANCIACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/financiacion/patagonia-leasing.php">Patagonia Leasing</a></li>
						<li><a href="../../empresas/financiacion/mercado-capitales.php">Mercado Capitales</a></li>
						<li><a href="../../empresas/financiacion/alternativas-de-financiacion.php">Alternativas de Financiación</a></li>
                        <li><a href="../../empresas/financiacion/convenios-de-financiacion.php">Convenios de Financiación</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../empresas/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../empresas/inversiones/compra-venta-titulos-acciones.php">Compra - Venta de Títulos y Acciones</a></li>
						<li><a href="../../empresas/inversiones/custodia-de-titulos.php">Custodia de Títulos</a></li>
						<li><a href="../../empresas/inversiones/fidecomisos-financieros.php">Fidecomisos Financieros</a></li>
						<li><a href="../../empresas/inversiones/plazos-fijos.php">Plazos Fijos</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
                        <li><a href="../../empresas/patagonia-movil-empresas.php">Patagonia Móvil Empresas</a></li>
						<li><a href="../../empresas/servicios/pagos.php">Pagos</a></li>
						<li><a href="../../empresas/servicios/recaudaciones.php">Recuadaciones</a></li>
						<li><a href="../../empresas/servicios/pago-de-servicios.php">Pago de Servicios</a></li>
						<li><a href="../../empresas/servicios/interbanking.php">Interbanking</a></li>
						<li><a href="../../empresas/servicios/interfacturas.php">Interfacturas</a></li>
						<li><a href="../../empresas/servicios/tarjetas-comerciales.php">Tarjetas Comerciales</a></li>
                        <!-- -->
						<!--<li><a href="../../empresas/servicios/comercios-patagonia.php">Comercios Patagonia</a></li>-->
                        <!-- -->
                        <li><a href="../../empresas/servicios/centro-atencion-empresas.php">Centro de Atención para Empresas</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN EMPRESAS -->
        
        <!-- SECTOR PÚBLICO -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">SECTOR PÚBLICO <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../sector-publico/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">INVERSIONES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/inversiones/fondos-comunes-de-inversion.php">Fondos Comunes de Inversión</a></li>
						<li><a href="../../sector-publico/inversiones/plazo-fijo.php">Plazo Fijo</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">SERVICIOS</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/servicios/servicio-de-recaudacion.php">Servicio de Recaudación</a></li>
						<li><a href="../../sector-publico/servicios/servicio-de-pagos.php">Servicio de Pagos</a></li>
						<li><a href="../../sector-publico/servicios/servicios-para-personal.php">Servicios para el Personal</a></li>
						<li><a href="../../sector-publico/servicios/financiacion.php">Financiación</a></li>
						<li><a href="../../sector-publico/servicios/otros-servicios.php">Servicios</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">PROGRAMA UNIVERSIDADES</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../sector-publico/programa-universidades/relacion-institucional.php">Relación Institucional</a></li>
						<li><a href="../../sector-publico/programa-universidades/docentes-yno-docentes.php">Docentes y No Docentes</a></li>
						<li><a href="../../sector-publico/programa-universidades/alumnos.php">Alumnos</a></li>
						<li><a href="../../sector-publico/programa-universidades/graduados.php">Graduados</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN SECTOR PUBLICO -->
        
        <!-- INSTITUCIONAL -->
		<li class="nav-main-item"><a href="#" class="has-sub-items ">INSTITUCIONAL <i class="fa fa-angle-right"></i></a>
			<ul class="list-unstyled">
				<li class="nav-sub-item"><a href="../../institucional/index.php" class="">HOME</a></li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">BANCO PATAGONIA</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/banco-patagonia/historia.php">Historia</a></li>
						<li><a href="../../institucional/banco-patagonia/mercado-de-capitales.php">Mercado de Capitales</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-inversora.php">Patagonia Inversora</a></li>
						<li><a href="../../institucional/banco-patagonia/patagonia-valores-sa.php">Patagonia Valores S.A</a></li>
						<li><a href="https://bp.bancopatagonia.com.ar/relacion-con-inversores/es/institucional" target="_blank">Relación con Inversores</a></li>
						<li><a href="../../institucional/banco-patagonia/desarrollo-humano.php">Desarrollo Humano</a></li>
						<li><a href="../../institucional/banco-patagonia/sustentabilidad.php">Sustentabilidad</a></li>
						<li><a href="../../institucional/banco-patagonia/politicas-aml-cft.php">Póliticas AML/CFT</a></li>
						<li><a href="../../institucional/banco-patagonia/disciplina-del-mercado.php">Disciplina de Mercado</a></li>
                        <li><a href="../../institucional/banco-patagonia/asistencia-a-vinculados.php">Asistencia a vinculados</a></li>
                        <li><a href="../../institucional/banco-patagonia/etica-e-integridad.php">Ética e Integridad</a></li>
					</ul>
				</li>
				<li class="nav-sub-item"><a href="#" class="has-sub-menu ">ORGANIZACIÓN</a>
					<ul class="list-unstyled submenu">
						<li><a href="../../institucional/organizacion/accionistas.php">Accionistas</a></li>
						<li><a href="../../institucional/organizacion/autoridades.php">Autoridades</a></li>
                        <li><a href="../../institucional/organizacion/comites.php">Comités</a></li>
						<li><a href="../../institucional/organizacion/sector-financiero.php">Sector Financiero</a></li>
					</ul>
				</li>
			</ul>
		</li>
        <!-- FIN INSTITUCIONAL -->
        
        <li class="nav-main-item"><a href="https://tunuevacuenta.bancopatagonia.com.ar/?utm_source=sitiowebbp&utm_medium=sitiowebbp%20banner%20home&utm_campaign=onboarding_sitiowebp_bannerhome" target="_blank" style="text-transform: none;">Hacete cliente</a></li>		<li class="nav-main-item"><a href="../../canales-de-atencion/index.php" class="" style="text-transform: none;">Canales de Atención</a></li>
		<!--<li class="nav-main-item"><a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank" style="text-transform: none;">Sucursales y Cajeros</a></li>-->
		<!--<li class="nav-main-item"><a href="<php echo $folder_contactenos ?>index.php" class="<php echo $contactenos ?>" style="text-transform: none;">Contactanos</a></li>-->
        <li class="nav-main-item"><a href="../../ayuda/index.php" class="" style="text-transform: none;">Ayuda</a></li>
        
	</ul>
</div>    <!-- -->
    <section class="sec-head">
    <!--<div class="sec-pic-head xs-head-position-x-60" style="background-image: url(<php echo $pathfolder ?>images/head-beneficios-exclusivos.jpg);">-->
    <div class="sec-pic-head" id="head-beneficios-exclusivos" title="Clientes singulares, beneficios singulares">
        <!--
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-6 col-xs-12 sec-pic-area">
                    <div class="sec-head-card">
                        <h2 class="with-border">Patagonia Singular</h2>
                        <p>&nbsp;</p>
                    </div>
                </div>
            </div>
        </div>
        -->
    </div>
</section>    <!-- -->
    <section class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <ol class="breadcrumb">
                    <li><a href="../index.php">Personas</a></li>
                    <li>Patagonia Singular</li>
                    <li class="active">Beneficios Exclusivos</li>
                </ol>
            </div>
        </div>
    </section>
    <!-- -->
    <section class="container">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="text-data">
                <!-- -->
                <!--<h1 class="clr-singular">Agosto Singular</h1>-->
                <!-- -->
                
                <div>
                    <!-- -------------- -->
                    <!-- BENEFICIO MODO -->
                    <!-- -------------- -->
                    <style>

                    </style>
                    <!-- TITULO -->
                    <h2 class="clr-singular" style="line-height: 1.2em;">Vos y un ahorrar con <img style="width: 66px; margin: -5px 0px 0px 2px;" src="../../assets/images/layout/logo-modo.svg" alt="Modo">. Vos y lo que querés.</h2>
                    <p class="clr-singular">Aprovechá todos los descuentos que tenés pagando con MODO desde Patagonia Móvil.</p>
                    <!--<p style="color: #00b9ad;"><strong>¡Además pagando con QR participas del sorteo de un smartphone por semana!</strong></p>-->
                    <p>Conocé todos los beneficios <a href="../tarjetas/beneficios-modo.php">acá</a>.</p>
                    <!-- -->
                </div>
				
				<!-- -->
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="text-data">
                            <hr>
                        </div>
                    </div>
                </div>
                <!-- -->
				
                <div>
                    <!-- --------- -->
                    <!-- BENEFICIO -->
                    <!-- --------- -->
                    <!-- TITULO -->
                    <h2 class="clr-singular"><strong>Havanna</strong></h2>
                    <!-- PROMOCION -->
                    <div class="bnf-box bnf-singular">
                        <div class="bnf-card">
                            <i class="bnf-icon bnf-icon-chocolate"></i>
                            <!--<i class="bnf-misc"></i>-->
                            <p>&nbsp;</p>
                            <big>30<span>%<sup>(1)</sup></span></big>
                            <p>de descuento</p>
                        </div>
                        <div class="bnf-card-data bnf-3-lines">
                            <p>Se aplica con Tarjetas de Crédito.</p>
                            <p>Todos los días.</p>
                            <p>Tope $5000.</p>
                        </div>
                    </div>
                    <!-- TEXTO -->
                    <p class="clr-singular"><strong>Vigencia: del 1 de junio al 31 de julio</strong></p>
                    <!--<p>Click en el logo para ver los locales adheridos</p>-->
                    <!-- ADHERIDOS -->
                    <div class="row">
                        <div class="col-md-2 col-sm-4 col-xs-6">
                            <!--<a href="#havanna" data-toggle="modal">-->
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_havanna.jpg" alt="Havanna">
                            <!--</a>-->
                        </div>  
                    </div>
                    <!-- -->
                </div>
				
				<!-- -->
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="text-data">
                            <hr>
                        </div>
                    </div>
                </div>
                <!-- -->
				
				<div>
					<!-- ---------- -->
                    <!-- PEDIDOS YA -->
                    <!-- ---------- -->
					<!-- TITULO -->
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<h2 class="clr-singular"><strong>Pedidos Ya</strong></h2>
						</div>
					</div>
					<!-- PROMOCION -->
					<div class="row">
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-12 col-xs-12">
							<!-- -->
							<div class="bnf-box bnf-singular">
								<div class="bnf-card">
									<i class="bnf-icon bnf-icon-shop-online"></i>
									<i class="bnf-misc"></i>
									<p>&nbsp;</p>
									<big>35<span>%<sup>(2)</sup></span></big>
									<p>de descuento</p>
								</div>
								<div class="bnf-card-data bnf-3-lines">
									<p>Se aplica con Tarjetas de Crédito.</p>
									<p>Todos los jueves.</p>
									<p>Tope $3000.</p>
								</div>
							</div>
							<!-- -->
						</div>
						<!-- -->
						<!--<div class="col-md-0 col-sm-0 col-xs-12 tbl">
							<div class="text-data">
								<hr>
							</div>
						</div>
						<div class="col-md-0 col-sm-0 col-xs-12 mbl">
							<div class="text-data">
								<hr>
							</div>
						</div>-->
						<!-- COLUMNA -->
						<div class="col-md-6 col-sm-12 col-xs-12">
							<!-- -->
							<div class="bnf-box bnf-singular">
								<div class="bnf-card">
									<i class="bnf-icon bnf-icon-shop-online"></i>
									<i class="bnf-misc"></i>
									<p>&nbsp;</p>
									<big>45<span>%<sup>(3)</sup></span></big>
									<p>de descuento</p>
								</div>
								<div class="bnf-card-data bnf-4-lines">
									<p><strong>Exclusivo con Tarjeta de Crédito</strong></p>
									<p><strong>American Express Black.</strong></p>
									<p>Todos los viernes y sábados.</p>
									<p>Tope $5000.</p>
								</div>
							</div>
							<!-- -->
						</div>
						<!-- -->
					</div>
					<!-- TEXTO -->
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<p class="clr-singular"><strong>Vigencia: del 1 de junio al 31 de julio</strong></p>
						</div>
					</div>
                    <!-- ADHERIDOS -->
                    <div class="row">
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <!--<a href="#pedidosya" data-toggle="modal">-->
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_pedidos_ya.jpg" alt="">
                            <!--</a>-->
                        </div>  
                    </div>
                    <!-- -->
				</div>
                
                <!-- -->
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="text-data">
                            <hr>
                        </div>
                    </div>
                </div>
                <!-- -->
                
                <div>
                    <!-- ------------ -->
                    <!-- RESTAURANTES -->
                    <!-- ------------ -->
                    <!-- TITULO -->
                    <h2 class="clr-singular"><strong>Restaurantes y Confiterías Seleccionados</strong></h2>
                    <!-- PROMOCION -->
                    <div class="bnf-box bnf-singular">
                        <div class="bnf-card">
                            <i class="bnf-icon bnf-icon-food"></i>
                            <i class="bnf-misc"></i>
                            <p>hasta</p>
                            <big>30<span>%<sup>(4)</sup></span></big>
                            <p>de descuento</p>
                        </div>
                        <div class="bnf-card-data bnf-2-lines">
                            <p>Se aplica con Tarjetas de Crédito y Tarjetas de Débito.</p>
                            <p>Tope hasta $5000.</p>
                        </div>
                    </div>
                    <!-- TEXTO -->
                    <p class="clr-singular"><strong>Presencial</strong></p>
                    <p>Click en cada logo para ver los locales adheridos</p>
                    <!-- ADHERIDOS -->
                    <div class="row">
						<!-- (ALB) -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <!--<a href="#" data-toggle="modal">-->
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_albertos_lobby_bar.jpg" alt="Albertos Lobby Bar">
                            <!--</a>-->
                        </div>
                        <!-- (ALD) -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#aldos" data-toggle="modal">
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_aldos.jpg" alt="Aldos">
                            </a>
                        </div>
                        <!-- modal -->
                        <div class="modal fade" id="aldos">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="text-data">
                                            <img src="../tarjetas/images/logos/logo_aldos.jpg" alt="Aldos">
                                            <p>&nbsp;</p>
                                            <h3 class="clr-singular"><strong>Locales Adheridos</strong></h3>
                                            <table class="table table-bordered" style="text-align:center;">
                                                <thead>
                                                    <tr>
                                                        <th width="50%" bgcolor="#eeeeee" style="text-align:center;">Dirección</th>
														<th width="50%" bgcolor="#eeeeee" style="text-align:center;">Localidad</th>
                                                    </tr>
                                                </thead>
                                                <tr>
                                                    <td>AREVALO 2032</td>
                                                    <td>CABA</td>
                                                </tr>
                                                <tr>
                                                    <td>REP ARABE SIRIA 3037</td>
                                                    <td>CABA</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- (CAB) -->
                        <!-- marca -->
                        <!--
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#cabanalaslilas" data-toggle="modal">
                                <img class="img-responsive" src="<php echo $folder_tarjetas ?>images/logos/logo_cabana_las_lilas.jpg" alt="Cabaña Las Lilas">
                            </a>
                        </div>
                        -->
                        <!-- modal -->
                        <!--
                        <div class="modal fade" id="cabanalaslilas">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="text-data">
                                            <img src="<php echo $folder_tarjetas ?>images/logos/logo_cabana_las_lilas.jpg" alt="Cabaña Las Lilas">
                                            <p>&nbsp;</p>
                                            <h3 class="clr-singular"><strong>Locales Adheridos</strong></h3>
                                            <table class="table table-bordered" style="text-align:center;">
                                                <thead>
                                                    <tr>
                                                        <th width="100%" bgcolor="#eeeeee" style="text-align:center;">Dirección</th>
                                                    </tr>
                                                </thead>
                                                <tr>
                                                    <td>Av. Alicia Moreau de Justo 516, CABA.</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        -->
                        <!-- (CAN) -->
                        <!-- marca -->
                        <!--
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#" data-toggle="modal">
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_canta_el_gallo.jpg" alt="Canta El Gallo">
                            </a>
                        </div>
                        -->
                        <!-- (CUC) -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#cucinadonore" data-toggle="modal">
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_cucina_donore.jpg" alt="Cucina Donore">
                            </a>
                        </div>
                        <!-- modal -->
                        <div class="modal fade" id="cucinadonore">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="text-data">
                                            <img src="../tarjetas/images/logos/logo_cucina_donore.jpg" alt="Cucina Donore">
                                            <p>&nbsp;</p>
                                            <h3 class="clr-singular"><strong>Locales Adheridos</strong></h3>
                                            <table class="table table-bordered" style="text-align:center;">
                                                <thead>
                                                    <tr>
                                                        <th width="50%" bgcolor="#eeeeee" style="text-align:center;">Dirección</th>
                                                        <th width="50%" bgcolor="#eeeeee" style="text-align:center;">Localidad</th>
                                                    </tr>
                                                </thead>
                                                <tr>
                                                    <td>AV. ALICIA MORO DE JUSTO 1768</td>
                                                    <td>CABA</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- (DAN) -->
                        <!-- marca -->
                        <!--
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#dandy" data-toggle="modal">
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_dandy.jpg" alt="Dandy">
                            </a>
                        </div>
                        -->
                        <!-- modal -->
                        <!--
                        <div class="modal fade" id="dandy">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="text-data">
                                            <img src="../tarjetas/images/logos/logo_dandy.jpg" alt="Dandy">
                                            <p>&nbsp;</p>
                                            <h3 class="clr-singular"><strong>Locales Adheridos</strong></h3>
                                            <table class="table table-bordered" style="text-align:center;">
                                                <thead>
                                                    <tr>
                                                        <th width="100%" bgcolor="#eeeeee" style="text-align:center;">Dirección</th>
                                                    </tr>
                                                </thead>
                                                <tr>
                                                    <td>Av. del Libertador 2410, CABA.</td>
                                                </tr>
                                                <tr>
                                                    <td>C, Av. Santa Fe 801, CABA.</td>
                                                </tr>
                                                <tr>
                                                    <td>Olga Cossettini 711, CABA.</td>
                                                </tr>
                                                <tr>
                                                    <td>Pinto 3880, CABA.</td>
                                                </tr>
                                                <tr>
                                                    <td>Av. del Libertador 2004, CABA.</td>
                                                </tr>
                                                <tr>
                                                    <td>Av. del Libertador 14.805, Acassuso.</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        -->
						<!-- (EL-F) -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <!--<a href="#" data-toggle="modal">-->
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_el_faro.jpg" alt="El Faro">
                            <!--</a>-->
                        </div>
                        <!-- (LA-B) -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <!--<a href="#" data-toggle="modal">-->
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_la_braseria.jpg" alt="La Brasería">
                            <!--</a>-->
                        </div>
                        <!-- (LA-C) -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <!--<a href="#lacabrera" data-toggle="modal">-->
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_la_cabrera.jpg" alt="La Cabrera">
                            <!--</a>-->
                        </div>
                        <!-- (LA-V) -->
                        <!-- marca -->
                        <!--
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#" data-toggle="modal">
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_la_vaqueria.jpg" alt="La Vaquería">
                            </a>
                        </div>
                        -->
                        <!-- (LAS-P) -->
                        <!-- marca -->
                        <!--
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#laspizarras" data-toggle="modal">
                                <img class="img-responsive" src="<php echo $folder_tarjetas ?>images/logos/logo_las_pizarras.jpg" alt="Las Pizarras">
                            </a>
                        </div>
                        -->
                        <!-- modal -->
                        <!--
                        <div class="modal fade" id="laspizarras">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="text-data">
                                            <img src="<php echo $folder_tarjetas ?>images/logos/logo_las_pizarras.jpg" alt="Las Pizarras">
                                            <p>&nbsp;</p>
                                            <h3 class="clr-singular"><strong>Locales Adheridos</strong></h3>
                                            <table class="table table-bordered" style="text-align:center;">
                                                <thead>
                                                    <tr>
                                                        <th width="100%" bgcolor="#eeeeee" style="text-align:center;">Dirección</th>
                                                    </tr>
                                                </thead>
                                                <tr>
                                                    <td>Thames 2296, CABA.</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        -->
                        <!-- (NU) -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#nucha" data-toggle="modal">
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_nucha.jpg" alt="Nucha">
                            </a>
                        </div>
                        <!-- modal -->
                        <div class="modal fade" id="nucha">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                      <div class="text-data">
                                        <img src="../tarjetas/images/logos/logo_nucha.jpg" alt="Nucha">
                                            <p>&nbsp;</p>
                                        <h3 class="clr-singular"><strong>Locales Adheridos</strong></h3>
                                          <table class="table table-bordered" style="text-align:center;">
                                              <thead>
                                                  <tr>
                                                      <th width="50%" bgcolor="#eeeeee" style="text-align:center;">Dirección</th>
                                                      <th width="50%" bgcolor="#eeeeee" style="text-align:center;">Localidad</th>
                                                  </tr>
                                              </thead>
                                              <tr>
                                                <td>ZABALA    2206, ESQUINA O´HIGGINS</td>
                                                <td>CABA</td>
                                              </tr>
                                              <tr>
                                                <td>CACHIMAYO 395</td>
                                                <td>CABA</td>
                                              </tr>
                                              <tr>
                                                <td>DORREGO 1989</td>
                                                <td>CABA</td>
                                              </tr>
                                              <tr>
                                                <td>PARANA 1343</td>
                                                <td>CABA</td>
                                              </tr>
                                              <tr>
                                                <td>FLORIDA  737 </td>
                                                <td>CABA</td>
                                              </tr>
                                              <tr>
                                                <td>HONDURAS 4630</td>
                                                <td>CABA</td>
                                              </tr>
                                              <tr>
                                                <td>AV DE LOS    INCAS 3390</td>
                                                <td>CABA</td>
                                              </tr>
                                          </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- (OSA) -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <!--<a href="#" data-toggle="modal">-->
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_osaka.jpg" alt="Osaka">
                            <!--</a>-->
                        </div>
                        <!-- (PUER) -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <!--<a href="#" data-toggle="modal">-->
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_puerto_cristal.jpg" alt="Puerto Cristal">
                            <!--</a>-->
                        </div>
                        <!-- (RAB) -->
                        <!-- marca -->
                        <!--
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#" data-toggle="modal">
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_rabieta.jpg" alt="Rabieta">
                            </a>
                        </div>
                        -->
                        <!-- (ROCK) -->
                        <!-- marca -->
                        <!--
						<div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#rockfellers" data-toggle="modal">
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_rock_fellers.jpg" alt="Rock Fellers">
                            </a>
                        </div>
						-->
                        <!-- modal -->
                        <!--
						<div class="modal fade" id="rockfellers">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="text-data">
                                            <img src="../tarjetas/images/logos/logo_rock_fellers.jpg" alt="Rock Fellers">
                                            <p>&nbsp;</p>
                                            <h3 class="clr-singular"><strong>Locales Adheridos</strong></h3>
                                            <table class="table table-bordered" style="text-align:center;">
                                                <thead>
                                                    <tr>
                                                        <th width="100%" bgcolor="#eeeeee" style="text-align:center;">Dirección</th>
                                                    </tr>
                                                </thead>
                                                <tr>
                                                    <td>Las Magnolias 533, Ramal Pilar Km 50. Pilar - Buenos Aires.</td>
                                                </tr>
                                                <tr>
                                                    <td>Bv. Oroño 106 (esquina jujuy).</td>
                                                </tr>
                                                <tr>
                                                    <td>Alto Rosario Shopping / Junín 501. Rosario - Santa Fe.</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
						-->
                        <!-- (RUKA) -->
                        <!-- marca -->
                        <!--
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#" data-toggle="modal">
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_ruka_garden.jpg" alt="Ruka Garden">
                            </a>
                        </div>
                        -->
                        <!-- (SOL) -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <!--<a href="#" data-toggle="modal">-->
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_solomia.jpg" alt="Solomia">
                            <!--</a>-->
                        </div>
                        <!-- (SU-718) -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <!--<a href="#" data-toggle="modal">-->
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_sushi_718.jpg" alt="Sushi 718">
                            <!--</a>-->
                        </div>
                        <!-- (SU-OLA) -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#olazabalsushi" data-toggle="modal">
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_olazabal_sushi.jpg" alt="Olazabal Sushi">
                            </a>
                        </div>
                        <!-- modal -->
                        <div class="modal fade" id="olazabalsushi">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="text-data">
                                            <img src="../tarjetas/images/logos/logo_olazabal_sushi.jpg" alt="Olazabal Sushi">
                                            <p>&nbsp;</p>
                                            <h3 class="clr-singular"><strong>Locales Adheridos</strong></h3>
                                            <table class="table table-bordered" style="text-align:center;">
                                                <thead>
                                                    <tr>
                                                        <th width="50%" bgcolor="#eeeeee" style="text-align:center;">Dirección</th>
                                                        <th width="50%" bgcolor="#eeeeee" style="text-align:center;">Localidad</th>
                                                    </tr>
                                                </thead>
                                                <tr>
                                                    <td>OLAZABAL 2076</td>
                                                    <td>CABA</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- (TUC) -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#tucson" data-toggle="modal">
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_tucson.jpg" alt="Tucson">
                            </a>
                        </div>
                        <!-- modal -->
                        <div class="modal fade" id="tucson">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="text-data">
                                            <img src="../tarjetas/images/logos/logo_tucson.jpg" alt="Tucson">
                                            <p>&nbsp;</p>
                                            <h3 class="clr-singular"><strong>Locales Adheridos</strong></h3>
                                            <table class="table table-bordered" style="text-align:center;">
                                                <thead>
                                                    <tr>
                                                        <th width="50%" bgcolor="#eeeeee" style="text-align:center;">Dirección</th>
                                                        <th width="50%" bgcolor="#eeeeee" style="text-align:center;">Localidad</th>
                                                    </tr>
                                                </thead>
                                                <tr>
                                                  <td>ARCOS 3630</td>
                                                  <td>NUÑEZ</td>
                                                </tr>
                                                <tr>
                                                  <td>PARANA 3745 - LOC 1182 PB</td>
                                                  <td>MARTINEZ</td>
                                                </tr>
                                                <tr>
                                                  <td>PARANA 3745 LOC 3315 1ER PISO</td>
                                                  <td>MARTINEZ</td>
                                                </tr>
                                                <tr>
                                                  <td>PARANA 3745 LOC 3091</td>
                                                  <td>MARTINEZ</td>
                                                </tr>
                                                <tr>
                                                  <td>VEDIA 3626</td>
                                                  <td>CABA</td>
                                                </tr>
                                                <tr>
                                                  <td>URIARTE 1641</td>
                                                  <td>CABA</td>
                                                </tr>
                                                <tr>
                                                  <td>LAS MAGNOLIAS 754 - PALMAS DEL PILAR</td>
                                                  <td>PILAR</td>
                                                </tr>
                                                <tr>
                                                  <td>JUAN MANUEL DE ROSAS 658- LOC 2251</td>
                                                  <td>CASTELAR</td>
                                                </tr>
                                                <tr>
                                                  <td>FELIX OLMEDO 2018</td>
                                                  <td>ROGELIO MARTINEZ - CORDOBA</td>
                                                </tr>
                                                <tr>
                                                  <td>AV. RAFAEL NUÑEZ 3803, B CERRO LAS ROSAS</td>
                                                  <td>LAS ROSAS</td>
                                                </tr>
                                                <tr>
                                                  <td>LAS CAÑAS 1833-LA BARRACA MAL LOC 2</td>
                                                  <td>GUAYMALLEN - MENDOZA</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- (YAP) -->
                        <!-- marca -->
                        <!--
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#yapan" data-toggle="modal">
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_yapan.jpg" alt="Yapan">
                            </a>
                        </div>
                        -->
                        <!-- modal -->
                        <!--
                        <div class="modal fade" id="yapan">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="text-data">
                                            <img src="../tarjetas/images/logos/logo_yapan.jpg" alt="Yapan">
                                            <p>&nbsp;</p>
                                            <h3 class="clr-singular"><strong>Locales Adheridos</strong></h3>
                                            <table class="table table-bordered" style="text-align:center;">
                                                <thead>
                                                    <tr>
                                                        <th width="100%" bgcolor="#eeeeee" style="text-align:center;">Dirección</th>
                                                    </tr>
                                                </thead>
                                                <tr>
                                                    <td>Franklin D. Roosevelt 1895 CABA.</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        -->
                        <!-- (ZIO) -->
                        <!-- marca -->
                        <!--
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <a href="#" data-toggle="modal">
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_zio_paco.jpg" alt="Zio Paco">
                            </a>
                        </div>
                        -->
                        <!-- -->
                    </div>
                    
                </div>
            
                <!-- -->
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="text-data">
                            <hr>
                            <h1 class="clr-singular">Además beneficios todas las semanas</h1>
                        </div>
                    </div>
                </div>
                <!-- -->
            
                <div>
                    <!-- --------- -->
                    <!-- CARREFOUR -->
                    <!-- --------- -->
                    <!-- TITULO -->
                    <h2 class="clr-singular"><strong>Carrefour</strong></h2>
                    <!-- PROMOCION -->
                    <div class="bnf-box bnf-singular">
                        <div class="bnf-card">
                            <i class="bnf-icon bnf-icon-cart"></i>
                            <!--<i class="bnf-misc"></i>-->
                            <p>&nbsp;</p>
                            <big>20<span>%<sup>(5)</sup></span></big>
                            <p>de descuento</p>
                        </div>
                        <div class="bnf-card-data bnf-3-lines">
                            <p>Se aplica con Tarjetas de Crédito y Tarjetas de Débito.</p>
                            <p>Todos los miércoles.</p>
                            <p>Tope $5000.</p>
                        </div>
                    </div>
                    <!-- TEXTO -->
                    <!--<p>Click en el logo para compras online</p>-->
                    <!-- ADHERIDOS -->
                    <div class="row">
                        <!-- 01 -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <!--<a href="#" data-toggle="modal">-->
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_carrefour.jpg" alt="Carrefour">
                            <!--</a>-->
                        </div>  
                        <!-- -->
                    </div>
                    <!-- -->
                </div>
            
                <!-- -->
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="text-data">
                            <hr>
                        </div>
                    </div>
                </div>
                <!-- -->

                <div>
                    <!-- --------- -->
                    <!-- CHANGOMAS -->
                    <!-- --------- -->
                    <!-- TITULO -->
                    <h2 class="clr-singular"><strong>ChangoMas</strong></h2>
                    <!-- PROMOCION -->
                    <div class="bnf-box bnf-singular">
                        <div class="bnf-card">
                            <i class="bnf-icon bnf-icon-cart"></i>
                            <!--<i class="bnf-misc"></i>-->
                            <p>&nbsp;</p>
                            <big>20<span>%<sup>(6)</sup></span></big>
                            <p>de descuento</p>
                        </div>
                        <div class="bnf-card-data bnf-3-lines">
                            <p>Se aplica con Tarjetas de Crédito.</p>
                            <p>Todos los viernes.</p>
                            <p>Tope $5000.</p>
                        </div>
                    </div>
                    <!-- TEXTO -->
                    <h3 class="clr-singular"><strong><span style="font-size: 40px;">10%</span> adicional</strong> pagando con <img style="width: 60px; margin: -5px 0px 0px 2px;" src="../../assets/images/layout/logo-modo.svg" alt="Modo"> con Tarjetas de Crédito Visa y Master. Tope $1000 <sup>(7)</sup></h3>
                    <!--<p class="clr-singular"><strong>Vigencia: hasta el 30 de abril</strong></p>-->
                    <!--<p>Click en el logo para compras online</p>-->
                    <!-- ADHERIDOS -->
                    <div class="row">
                        <!-- 01 -->
                        <!-- marca -->
                        <div class="col-md-2 col-sm-3 col-xs-6">
                            <!--<a href="#" data-toggle="modal">-->
                                <img class="img-responsive" src="../tarjetas/images/logos/logo_chango_mas.jpg" alt="ChangoMas">
                            <!--</a>-->
                        </div>  
                        <!-- -->
                    </div>
                    <!-- -->
                </div>
            
                <!-- -->
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="text-data">
                            <hr>
                        </div>
                    </div>
                </div>
                <!-- -->
                
                <!-- -------------------------------------- -->
                <!-- ADEMAS BENEFICIOS TODAS LAS SEMANAS EN -->
                <!-- -------------------------------------- -->
                <!-- TITULO -->
                <!--<h1 class="clr-singular">Además beneficios todas las semanas</h1>-->
                <!-- PROMOCIONES -->
                <!--<div class="bnf-container bnf-flex">-->
                <div class="row">
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <!-- restaurantes (col 1) -->
                        <div class="bnf-box bnf-singular">
                            <div class="bnf-card">
                                <i class="bnf-icon bnf-icon-food"></i>
                                <i class="bnf-misc"></i>
                                <p>Restaurantes</p>
                                <big>30<span>%<sup>(8)</sup></span></big>
                                <!--<p>de descuento</p>-->
                            </div>
                            <div class="bnf-card-data bnf-5-lines">
                                <p>Se aplica con Tarjetas de Crédito.</p>
                                <p>Todos los viernes.</p>
                                <p>Tope $4000.</p>
                                <p><strong>Clientes Singular Plan Sueldos:</strong></p>
                                <p><strong>Tope $5000.</strong></p>
                            </div>
                        </div>
                        <!-- -->
                        <br class="mbl">
                        <!-- -->
                    </div>
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <!-- restaurantes amex black (col 1) -->
                        <div class="bnf-box bnf-singular">
                            <div class="bnf-card">
                                <i class="bnf-icon bnf-icon-food"></i>
                                <i class="bnf-misc"></i>
                                <p>Restaurantes</p>
                                <big>40<span>%<sup>(9)</sup></span></big>
                                <!--<p>de descuento</p>-->
                            </div>
                            <div class="bnf-card-data bnf-4-lines">
                                <p><strong>Exclusivo con Tarjeta de Crédito</strong></p>
                                <p><strong>American Express Black.</strong></p>
                                <p>Todos los viernes.</p>
                                <p>Tope $6000.</p>
                            </div>
                        </div>
                        <!-- -->
                        <br class="mbl">
                        <!-- -->
                    </div>
                </div>
                <!--</div>-->
                <!--<br class="mbl">-->
                <!--<div class="bnf-container bnf-flex">-->
                <div class="row">
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <!-- combustible -->
                        <div class="bnf-box bnf-singular">
                            <div class="bnf-card">
                                <i class="bnf-icon bnf-icon-fuel"></i>
                                <i class="bnf-misc"></i>
                                <p>Combustible</p>
                                <big>20<span>%<sup>(10)</sup></span></big>
                                <!--<p>de descuento</p>-->
                            </div>
                            <div class="bnf-card-data bnf-4-lines">
                                <p>Se aplica con Tarjetas de Crédito</p>
                                <p>y Tarjetas de Débito.</p>
                                <p>Todos los jueves.</p>
                                <p>Tope $3000</p>
                            </div>
                        </div>
                        <!-- -->
                        <br class="mbl">
                        <!-- -->
                    </div>
                </div>
                <!--</div>-->
                <!--<br class="mbl">-->
                <!--<div class="bnf-container bnf-flex">-->
                <!--
                <div class="row">
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        
                    </div>
                    
                </div>
                -->
                <!--</div>-->
                
                <!-- -->
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="text-data">
                            <hr>
                        </div>
                    </div>
                </div>
                <!-- -->
                
                <div class="row legal-int">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="legal-flex">
                            <!-- -->
                            <div class="lf-p-cft">
                                <p>(*) PARA COMPRAS ABONADAS EN CUOTAS POR USUARIOS DE SERVICIOS FINANCIEROS - CARTERA DE CONSUMO - SE APLICARÁ: TASA NOMIN AL ANUAL: 0% - TASA EFECTIVA ANUAL: 0% - COSTO SEGURO DE VIDA 0% - COSTO FINANCIERO TOTAL (C.F.T.) EXPRESADO EN TASA EFECTIVA. (**) PARA COMPRAS ABONADAS EN CUOTAS POR CLIENTES DE CARTERA COMERCIAL, SE APLICARÁ: TASA NOMINAL ANUAL: 0% - TASA EFECTIVA ANUAL: 0% - COSTO SEGURO DE VIDA 0.35% - COSTO FINANCIERO TOTAL. ESTA PROMOCIÓN SE AJUSTA A LA RESOLUCIÓN 51 E/2017 DE LA SECRETARÍA DE COMERCIO SIENDO LAS CUOTAS SIN INTERÉS. COSTO FINANCIERO TOTAL. PROMOCIONES CONFORME RESOLUCIÓN 51 E/2017 DE LA SECRETARÍA DE COMERCIO.</p>
                            </div>
                            <!-- -->
                            <div class="lf-cft">
    <!--
    <p>COSTO FINANCIERO TOTAL EFECTIVO ANUAL:</p>
    <p style="font-size:20px;">C.F.T.E.A (CON Y SIN IVA): 0,00%(*); 4,34%(**)</p>
    -->
    <p style="font-size:50px;">C.F.T.N.A. (con y sin IVA):<br> (*) 0,00%<br> (**) 4,34%</p>
</div>                            <!-- -->
                            <div class="lf-p">
                                <p>CARTERA DE CONSUMO - EL IMPORTE AHORRADO EN LAS COMPRAS REALIZADAS CON LAS TARJETAS DE DÉBITO DEL BANCO SERÁ ACREDITADO EN LA CUENTA DE DÉBITO, DENTRO DE LOS 10 DÍAS HÁBILES DE REALIZADA LA OPERACIÓN; LOS REINTEGROS CORRESPONDIENTES A LAS COMPRAS EFECTUADAS EN CUOTAS -CON LAS TARJETAS DE CRÉDITO VISA, MASTERCARD Y AMERICAN EXPRESS DEL BANCO- SE VISUALIZARÁN EN EL RESUMEN EN QUE INGRESE LA PRIMERA CUOTA Y/O EN EL INMEDIATO POSTERIOR. BANCO PATAGONIA S.A. NO SE RESPONSABILIZA POR LOS CUPONES PRESENTADOS FUERA DE LAS FECHAS DE VIGENCIA DE LAS PROMOCIONES. LAS CUENTAS NO DEBERÁN REGISTRAR MORA. POR MES Y POR CUENTA. (1) PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA DES EL 01/06/24 AL 31/07/24 EN LOS COMERCIOS ADHERIDOS DE: HAVANNA, RECIBIRÁ 30% EN 1 PAGO CON TODAS LAS TARJETAS DE DÉBITO Y CRÉDITO DE BANCO PATAGONIA. TOPE POR MES Y POR CUENTA $5000.   EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO. (2) PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA LOS JUEVES, DESDE EL 01/06/2024 AL 31/07/2024 RECIBIRÁ UN 35% DE DESCUENTO CON TODAS LAS TARJETAS DE CRÉDITO DE BANCO PATAGONIA EN PEDIDOS YA TOPE POR MES Y CUENTA $3000. EL BENEFICIO NO APLICA PARA AQUELLOS PAGOS Y/O CONSUMOS ABONADOS CON TARJETAS DE DÉBITO Y CRÉDITO EMITIDAS POR BANCO PATAGONIA S.A. A TRAVÉS DE BILLETERAS VIRTUALES, POS MÓVILES, PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCIÓN DE MODO. (3) PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA LOS VIERNES Y SABADOS, DESDE EL 01/06/2024 AL 31/07/2024 RECIBIRÁ UN 45% DE DESCUENTO CON TODAS LAS TARJETAS DE CRÉDITO AMERICAN EXPRESS BLACK DE BANCO PATAGONIA EN PEDIDOS YA. TOPE POR MES Y CUENTA $5000.  EL BENEFICIO NO APLICA PARA AQUELLOS PAGOS Y/O CONSUMOS ABONADOS CON TARJETAS DE DÉBITO Y CRÉDITO EMITIDAS POR BANCO PATAGONIA S.A. A TRAVÉS DE BILLETERAS VIRTUALES, POS MÓVILES, PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCIÓN DE MODO. (4) DESDE EL 01/06/2024 AL 30/06/2024 EN LAS COMPRAS PRESENCIALES EN ALDO´S, LA BRASERÍA, SOLOMÍA, LA CABRERA, OSAKA, PUERTO CRISTAL, SUSHI 718, ALBERTOS LOBY BAR, EL FAROY NUCHA. RECIBIRÁ HASTA 30% DE DESCUENTO EN UN PAGO CON TODAS LAS TARJETAS DE CRÉDITO VISA SIGNATURE, MASTERCARD BLACK Y AMEX BLACK DE BANCO PATAGONIA. TOPE POR PLAZO DE VIGENCIA $5000. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXEPCIÓN DE MODO. (5) DESDE EL 01/06/2024 AL 31/07/2024. ABONANDO LOS MIÉRCOLES CON TODAS LA TARJETA DE DÉBITO PATAGONIA 24 Y LAS TARJETAS DE CRÉDITO EMITIDAS POR BANCO PATAGONIA S.A. RECIBIRÁ UN 20% DE DESCUENTO EN 1 PAGO EN LOS LOCALES HIPERMERCADOS CARREFOUR, CARREFOUR MARKET, CARREFOUR EXPRESS Y TAMBIÉN PROMOCIÓN VALIDA PARA WWW.CARREFOUR.COM.AR EN COMPRAS EN 1 PAGO Y PROGRAMANDO LA ENTREGA DE TU PEDIDO PARA LOS MIÉRCOLES. SE EXCLUYE, ELECTRÓNICA, ELECTRODOMÉSTICOS Y TELEFONÍA CELULAR. SE EXCLUYEN ADICIONALES DE TARJETA DE DÉBITO. PROMOCIÓN NO ACUMULABLE CON OTRAS PROMOCIONES. TOPE DE DEVOLUCIÓN $5000 POR MES Y POR CUENTA. NO PARTICIPA CARREFOUR MAXI. NO INCLUYE MOTOS, CUATRICICLOS, BICICLETAS MOTORIZADAS, TRACTORES, BODEGAS CHANDON, LEONCIO ARIZU, TERRAZAS DE LOS ANDES, TRUMPETER, LA RURAL, RUTINI WINES, LATITUD 33, CLOS DE LOS SIETE, CATENA ZAPATA, NI PRODUCTOS DE CONVENIO DE PRECIOS CUIDADOS, LECHES INFANTILES Y MATERNIZADAS ETAPA 1 Y 2 NI CARNICERÍA: CARNE VACUNA, POLLO, CORTES DE CERDOS Y EMBUTIDOS. NO INCLUYE PRODUCTOS DE LA MARCA CARREFOUR DE ALIMENTOS, LÁCTEOS, QUESOS, FIAMBRES, BEBIDAS, PERFUMERÍA Y LIMPIEZA. NO ACUMULABLE CON OTRAS PROMOCIONES VIGENTES. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXEPCIÓN DE MODO. (6) DESDE EL 01/06/2024 AL 31/07/2024. ABONANDO LOS VIERNES CON TODAS LAS TARJETAS DE CRÉDITO EMITIDAS POR BANCO PATAGONIA S.A. RECIBIRÁ UN 20% DE DESCUENTO EN 1 PAGO EN LOS SUPERMERCADOS CHANGOMAS. TOPE DE DEVOLUCIÓN $5000 POR MES Y POR CUENTA. (9)  ABONANDO EXCLUSIVO CON MODO CON LAS TARJETAS DE CREDITO VISA Y MASTERCARD RECIBIRA UN 10% ADICIONAL. TOPE DE DEVOLUCIÓN $1000 POR MES.SERÁ CONDICIÓN EXCLUYENTE, PREVIO A REALIZAR EL REINTEGRO, TENER ASOCIADA A MODO LA CUENTA DEL BANCO PATAGONIA. EL DESCUENTO PODRÁ VISUALIZARSE VÍA REINTEGRO, A ACREDITAR EN LA CUENTA DEL CLIENTE DENTRO DE LOS 30 DÍAS HÁBILES POSTERIORES A LA FECHA DE REALIZADA LA COMPRA. LA CUENTA NO DEBE REGISTRAR DEUDA O MORA EN BANCO PATAGONIA. PARA ACCEDER Y OPERAR EN PATAGONIA MÓVIL, DEBERÁ ENCONTRARSE PREVIAMENTE ADHERIDO AL SERVICIO PATAGONIA EBANK PERSONAS. EL USO DE PATAGONIA MÓVIL REQUIERE UN TELÉFONO CELULAR CON SISTEMA OPERATIVO ANDROID O IOS (IPHONE) CON ACCESO A INTERNET Y SERVICIO DE DATOS. PARA UTILIZAR DICHO SERVICIO DEBERÁ ACEPTAR PREVIAMENTE SUS TÉRMINOS Y CONDICIONES, LOS CUALES PODRÁN SER CONSULTADOS EN WWW.BANCOPATAGONIA.COM.AR O EN CUALQUIERA DE NUESTRAS SUCURSALES. SIEMPRE DESCARGUE LA APLICACIÓN PATAGONIA MÓVIL DE TIENDAS OFICIALES, NO ACCEDA DESDE LINKS QUE PROVENGAN DE MAILS O SMS. LOS COSTOS DE LA DESCARGA DE LA UTILIZACIÓN DE LA APLICACIÓN Y EL DE LA NAVEGACIÓN, SERÁN LOS QUE COBRE LA EMPRESA DE TELEFONÍA CELULAR UTILIZADA POR EL CLIENTE Y SERÁN A SU EXCLUSIVO CARGO. BANCO PATAGONIA S.A. NO SERÁ RESPONSABLE POR LOS ERRORES EN EL SOFTWARE DE LA APLICACIÓN, NI POR LA SUSPENSIÓN, INTERRUPCIÓN O FALLA DEL SERVICIO PROVENIENTE DE UNA MEDIDA UNILATERAL DE LA EMPRESA DE TELEFONÍA CELULAR. PARA MÁS INFORMACIÓN SOBRE EL SERVICIO DE MODO INGRESE A WWW.MODO.COM.AR. (10) DESDE EL 01/05/2024 AL 31/05/2024. ABONANDO LOS VIERNES CON LAS TARJETAS DE CRÉDITO DE BANCO PATAGONIA S.A., RECIBIRÁ UN 30% DE DESCUENTO EN COMPRAS PRESENCIALES EN LOS COMERCIOS REGISTRADOS BAJO EL RUBRO RESTAURANTES. TOPE DE DEVOLUCIÓN $4000 POR MES Y POR CUENTA. CLIENTES QUE ACREDITEN SUELDO EN BANCO PATAGONIA RECIBIRÁN UN 30% DE DESCUENTO, TOPE $5000 POR MES Y POR CUENTA. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXEPCIÓN DE MODO. (11) DESDE EL 01/05/2024 AL 31/05/2024 RECIBIRÁ UN 40% DE DESCUENTO EN LAS COMPRAS PRESENCIALES EN LOS COMERCIOS REGISTRADO COMO RUBRRO RESTAURANTES CON TODAS LAS TARJETAS DE CRÉDITO AMERICAN EXPRESS BLACK DE BANCO PATAGONIA. TOPE POR MES Y CUENTA $6000. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXEPCIÓN DE MODO. (12) DESDE EL 01/06/2024 AL 31/07/2024 ABONANDO LOS JUEVES CON LA TARJETA DE DÉBITO PATAGONIA 24 Y LAS TARJETAS DE CREDITO EMITIDAS POR BANCO PATAGONIA S.A., RECIBIRÁN UN 20% DE DESCUENTO EN LOS COMERCIOS REGISTRADOS BAJO EL RUBRO COMBUSTIBLE. NO ACUMULABLE CON OTRAS PROMOCIONES. TOPE DE DEVOLUCIÓN POR CUENTA Y POR MES: $3000. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXEPCIÓN DE MODO.</p>
                            </div>
                            <!-- -->
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>
<!-- EXTERNAL LNK -->
<!-- farmaonline -->
<div class="modal fade" id="farmaonline">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="https://www.farmaonline.com/" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<!-- canale -->
<div class="modal fade" id="canale">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="https://shop.bodegahcanale.com/bancopatagonia/ag/" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<!-- boating -->
<div class="modal fade" id="boating">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="http://www.boating.com.ar/" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<!-- style store -->
<div class="modal fade" id="stylestore">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="https://www.stylestore.com.ar/" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<!-- dafiti -->
<div class="modal fade" id="dafiti">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="http://www.dafiti.com.ar/promociones-bancarias-premium/" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<!-- gorsh -->
<div class="modal fade" id="gorsh">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="http://www.gorsh.com/" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<!-- fravega -->
<div class="modal fade" id="fravega">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="https://www.fravega.com/" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<!-- supermercados -->
<div class="modal fade" id="carrefour">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="http://www.carrefour.com.ar/" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="disco">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="http://www.disco.com.ar" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="jumbo">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="http://www.jumbo.com.ar" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="vea">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="http://www.veadigital.com.ar" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<!-- digital sport -->
<div class="modal fade" id="digitalsport">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="https://www.digitalsport.com.ar/" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<!-- sony -->
<div class="modal fade" id="sony">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="https://store.sony.com.ar/banco-patagonia" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<!-- canale -->
<div class="modal fade" id="canale">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span>X</span></button>
                <h4 class="modal-title"><img src="../../assets/images/layout/logo.svg" width="206" height="22" alt=""/></h4>
            </div>
            <div class="modal-body">
                <div class="external-legend">
                    <p>Estás abandonado el sitio de Banco Patagonia S.A. El usuario reconoce que las hiperconexiones con otro medios de Internet son a tu propio riesgo. Banco Patagonia no investiga, verifica, controla ni responde el contenido, la exactitud, las opiniones expresada y otras conexiones suministradas por estos medios. </p>
                </div>
            </div>
            <div class="modal-footer">
                <a href="https://shop.bodegahcanale.com/bancopatagonia" target="_blank" class="cta-btn">Aceptar</a>
                <a href="#" class="cta-btn-cancel" data-dismiss="modal">Cancelar</a>
            </div>
        </div>
    </div>
</div>
<!-- FIN EXTERNAL LNK -->    <!-- -->
	<div class="container-fluid footer-bar">
	<div class="row">
		<footer class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="flnks"><a href="../../registro-nacional-base-datos.php">Registro Nacional de Base de Datos</a> <span>|</span>   <a href="../../codigo-practicas-bancarias.php">Código de Prácticas Bancarias</a> <span>|</span>   <a href="../../defensa-ley-consumidor.php">Defensa del Consumidor</a>
						<span>|</span>   <a href="https://www.argentina.gob.ar/produccion/defensadelconsumidor/formulario">Defensa de las y los consumidores. Para reclamos ingrese aquí</a><span>|</span> <br class="tbl"> <a href="../../persona-expuesta-politicamente.php">Persona Expuesta Políticamente</a> <span class="tbl">|</span> <br class="dsk">
						
					<a href="../../agencia-acceso-informacion-publica.php">Agencia de Acceso a la Información Pública</a> <span>|</span> <br class="tbl"> 
					<a href="../../cnv-advertencia-publico-inversor.php">CNV - Advertencia al Público Inversor</a> <span>|</span> <a href="../../docs/Idoneos.pdf" target="_blank"> Idóneos en Mercado de Capitales - CNV</a><span>|</span>   <a href="../../codigo-proteccion-inversor.php">Código de Protección al Inversor</a> <span>|</span>   <a href="../../clausulas-legales.php">Cláusulas Legales</a> <span>|</span> <a href="../../resolucion-022021.php">Resol. 02/21 Dir.Gral. Defensa del consumidor Córdoba</a></p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<p class="redes">
                        <span>Seguinos en:</span>
                        <!-- -->
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><img src="../../assets/images/layout/icon-facebook.svg" alt="Facebook"></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><img src="../../assets/images/layout/icon-twitter.svg" alt="Twitter"></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><img src="../../assets/images/layout/icon-instagram.svg" alt="Instagram"></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><img src="../../assets/images/layout/icon-youtube.svg" alt="Youtube"></a>
                        <!-- -->
                        <!--
                        <a href="https://www.facebook.com/BancoPatagonia/" target="_blank"><i class="fa fa-facebook-square"></i></a>
                        <a href="https://twitter.com/banco_patagonia" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/banco_patagonia/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.youtube.com/user/bancopatagonia" target="_blank"><i class="fa fa-youtube-play"></i></a>
                        -->
                    </p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					                    <!---->
				    <p class="flegal">BANCO PATAGONIA S.A. ES UNA SOCIEDAD ANÓNIMA CONSTITUIDA BAJO LAS LEYES DE LA REPÚBLICA ARGENTINA CUYOS ACCIONISTAS LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRITAS DE ACUERDO A LA LEY 19.550. POR CONSIGUIENTE, Y EN CUMPLIMIENTO DE LA LEY 25.738, SE INFORMA QUE NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS RESPONDEN, EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA, POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA.</p>
                    <p class="flegal" style="font-size:10px;">Banco Patagonia S.A. - Agente de Liquidacion y Compensacion y Agente de Negociacion Integral, inscripto en CNV bajo el N° 66</p>
					<p class="flegal">© 2024 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación , distribución o almacenamiento en cualquier medio.</p>
				</div>
			</div>
		</footer>
	</div>
</div>
<div class="tbl mbl placeholder-shortlinks">
	<div class="container shortlinks">
		<div class="row">
                            <div class="col-sm-3 col-xs-3">
                    <a href="../../ayuda/index.php"><span class="icon icon-contacto"></span>Ayuda</a>
                </div>
                        			<div class="col-sm-3 col-xs-3">
				<a href="http://sucursalesycajeros.bancopatagonia.com.ar/sucursales.html" target="_blank"><span class="icon icon-sucursales"></span>Sucursales y Cajeros</a>
			</div>
			<div class="col-sm-3 col-xs-3">
				<a href="../../canales-de-atencion/index.php"><span class="icon icon-canales"></span>Canales de Atención</a>
			</div>
			<div class="col-sm-3 col-xs-3 last">
				<a href="../../empresas/patagonia-ebank-empresas-mbl.php"><span class="icon icon-ebank"></span>Patagonia e-Bank</a>
			</div>
		</div>
	</div>
</div>	<script src="../../assets/js/jquery-3.5.1.min.js"></script>
<script src="../../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../../assets/js/slick/slick.min.js"></script>
<script src="../../assets/js/fancybox/jquery.fancybox.min.js"></script>
<script src="../../assets/js/mtabs/jquery.bootstrap-responsive-tabs.min.js"></script>
<script src="../../assets/js/funciones.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics (original) -->
<!--
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-32588129-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-32588129-1');
</script>
-->

<!-- Google Analytics (version anterior / eventos ok)  -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-32588129-1', 'auto');
  ga('send', 'pageview');
</script>

<!-- GA4 - Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-C6LG1PT98X"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-C6LG1PT98X');
</script>
</body>
</html>