
<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Este archivo include solo va a estar habilitado en producción, en desarrollo se llama inc_gtm_head_po(bkp) para que no genere datos -->
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MX3X9FL');</script>
<!-- End Google Tag Manager -->

<!-- Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-Z028NHBWBH"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-Z028NHBWBH'); </script>
<!-- END Analytics -->	
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	
	<!-- --------- -->
	<!-- META TAGS -->
	<!-- --------- -->
			
    <!-- Primary Meta Tags -->
	<title>Sumate a Patagonia ON | 100% online y gratis</title>
    <meta name="title" content="Sumate a Patagonia ON | 100% online y gratis">
    <meta name="description" content="Si tenés entre 18 y 28 años, abrí tu cuenta 100% online, gratis y recibí hasta 10 luquitas de bienvenida.">
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="">
    <meta property="og:title" content="Sumate a Patagonia ON | 100% online y gratis">
    <meta property="og:description" content="Si tenés entre 18 y 28 años, abrí tu cuenta 100% online, gratis y recibí hasta 10 luquitas de bienvenida.">
    <meta property="og:image" content="https://www.bancopatagonia.com.ar/patagoniaon/image/ChicaSkateFinal3.png">
    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="">
    <meta property="twitter:title" content="Sumate a Patagonia ON | 100% online y gratis">
    <meta property="twitter:description" content="Si tenés entre 18 y 28 años, abrí tu cuenta 100% online, gratis y recibí hasta 10 luquitas de bienvenida.">
    <meta property="twitter:image" content="https://www.bancopatagonia.com.ar/patagoniaon/image/ChicaSkateFinal3.png">

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="favicon.ico" type="image/png" />

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <!-- Bootstrap core CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Slick CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css" integrity="sha512-wR4oNhLBHf7smjy0K4oqzdWumd+r5/+6QO/vDda76MW5iug4PT7v86FoEkySIJft3XA0Ae6axhIvHrqwm793Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css" integrity="sha512-6lLUdeQ5uheMFbWm3CP271l14RsX1xtx+J5x2yeIDkkiBpeVTNhTqijME7GgRKKi6hCqovwCoBTlRBEC20M8Mg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/style.css?v=20240608025626">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bodymovin/5.7.8/lottie.min.js"></script>
</head>

<body>
	<!-- Este archivo include solo va a estar habilitado en producción, en desarrollo se llama inc_gtm_body_po para que no genere datos -->
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="ns "
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->	
    <header class="main-header" id="main-header">
        <div class="container  ">
            <div class="row align-items-center justify-content-between">
                <div class="col-6 col-lg-2" data-menuanchor="hacete-on">
                    <a class="navbar-brand " href="#hacete-on">
                        PATAGONIA ON
                    </a>
                </div>

                <div class="col-6 d-lg-none d-flex justify-content-end align-items-center">
                    <a class="nav-link me-3" id="change-mode-mob">Mode</a>
                    <button class="navbar-toggle collapsed" type="button" data-bs-toggle="collapse"
                        data-bs-target="#mainMenu">
                        <span class="icon-bar icon-bar-1"></span>
                        <span class="icon-bar icon-bar-2"></span>
                        <span class="icon-bar icon-bar-3"></span>
                    </button>
                </div>

                <div class="col-12 col-md-10 col-lg-10 col-xl-8 col-xxl-6 d-lg-flex d-non">
                    <nav class="navbar navbar-expand-lg main-nav  ">
                        <div class="collapse navbar-collapse justify-content-lg-end" id="mainMenu">
                            <ul class="navbar-nav menu-idea" id="menu">
                                <li data-menuanchor="hacete-on">
                                    <a href="#hacete-on" class="nav-link">Hacete On</a>
                                </li>
                                <li data-menuanchor="beneficios" class="">
                                    <a href="#beneficios" class="nav-link ">Beneficios</a>
                                </li>
                                <li data-menuanchor="club-patagonia">
                                    <a href="#club-patagonia" class="nav-link">Club Patagonia</a>
                                </li>
                                <li data-menuanchor="billetera">
                                    <a href="#billetera" class="nav-link">Billetera</a>
                                </li>
                                <li data-menuanchor="inversiones">
                                    <a href="#inversiones" class="nav-link">Inversiones</a>
                                </li>
                                <li class="d-none d-lg-block">
                                    <a class="nav-link" id="change-mode">Mode</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <!-- /.container -->
    </header>

    <section class="section home" id="hacete-on">
                <div class="container" style="position:relative;">

            <div class="row align-items-end">
                <div class="col-12 d-none d-lg-block">
                    <div class="callto text-end ">
                        <p><i>¿Sos estudiante? <strong>Todavía hay más</strong></i></p>
                    </div>

                </div>
            </div>
        </div>
        <div class="container-fluid" style="position:relative;">

            <div class="row align-items-center justify-content-center justify-content-lg-between">
                <div class="col-12 col-lg-5 col-xl-4 px-0" id="animation_hero">
                    <div id="animation-container"></div>

                    <script>
                        // Selecciona el contenedor donde se mostrará la animación
                        const animationContainer = document.getElementById('animation-container');

                        // Configura las opciones de la animación
                        const animationOptions = {
                            container: animationContainer, // Contenedor HTML
                            renderer: 'svg', // Tipo de renderizador ('svg' o 'canvas')
                            loop: true, // Repetir la animación
                            autoplay: true, // Reproducir automáticamente la animación
                            path: 'lotties/ChicaSkate1.json' // Ruta al archivo JSON de la animación
                        };

                        // Carga y reproduce la animación Lottie
                        const anim = lottie.loadAnimation(animationOptions);
                    </script>

                    <img src="image/ChicaSkateFinal3.png" class="img-fluid d-none" />
                </div>
                <div class="col-12 col-lg-7">
                    <div class="promo-home">
                        <h3 class="promo-tit cero">$0</h3>
                        <div class="promo-desc">totalmente<br>gratis,<br><strong>sin costo</strong><sup>(1)</sup></div>
                    </div>

                    <div class="promo-home">
                        <h3 class="promo-tit">tarjeta<br>virtual</h3>
                        <div class="promo-desc"><strong>100% online</strong><br>sin esperar a<br>que llegue<br>el
                            plástico </div>
                    </div>

                    <div class="promo-home">
                        <h3 class="promo-tit">cuenta<br>completa</h3>
                        <div class="promo-desc">Caja de <strong>ahorro</strong>,<br>tarjeta de<br class="d-lg-none">
                            <strong>débito</strong> <br class="d-none d-lg-block"> y<br class="d-lg-none">
                            <strong>crédito</strong></div>
                    </div>

                    <div class="text-center text-lg-start">
                        <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" target="_blank" class="btn-common"><span>Abrí tu cuenta Patagonia On</span></a>
                        <a href="https://api.whatsapp.com/send/?phone=5491156350000&text=Hola!+%20&type=phone_number&app_absent=0" class="btn-padi" target="_blank">¡Chateá con Padi 24/7!</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="container" style="position:relative;">
            <div class="row align-items-end ">
                <div class="col-12 d-block d-lg-none my-3">
                    <div class="callto text-center ">
                        <p class="d-inline"><i>¿Sos estudiante? <strong>Todavía hay más</strong></i></p>
                    </div>

                </div>
            </div>
        </div>
        <div class="button_open-slide" id="toggle-overlay-open">
            <img src="image/open-slide.svg" class="img-fluid" id="btn_open_slide_light" />
            <img src="image/open-slide-dark.svg" class="img-fluid" id="btn_open_slide_dark" />
        </div>

        <div id="mobile_slider_controls">
            <button id="mobile_slider_control__slide1" class="active"></button>
            <button id="mobile_slider_control__slide2"></button>
        </div>

        <div class="overlay" id="overlay">
            <div class="button_close-slide" id="toggle-overlay-close">
                <img src="image/close-slide.svg" class="img-fluid" id="btn_close_slide_light" />
                <img src="image/close-slide-dark.svg" class="img-fluid" id="btn_close_slide_dark" />
            </div>
            
            <div class="container" style="position:relative;">
                <div class="row align-items-center">
                    <div class="col-12 col-lg-7">

                        <div class="promo-home">
                            <h3 class="promo-tit color-muta">descuentos</h3>
                            <div class="promo-desc promo-desc_azul color-muta">EN SUPERMERCADOS, <br class="d-none d-lg-block">PEDIDOS YA, CABIFY, <br class="d-none d-lg-block">BURGER KING <br class="d-none d-lg-block">Y MUCHOS MÁS.</div>
                        </div>

                        <div class="promo-home">
                            <h3 class="promo-tit color-muta">espacios <br class="d-none d-lg-block">exclusivos</h3>
                            <div class="promo-desc promo-desc_azul color-muta">EN + DE <br><strong>15 UNIVERSIDADES,</strong><br><a href="#" class="btn-conocelos modal-open" data-bs-toggle="modal" data-bs-target="#modalUniversidades">Conocelos acá</a></div>
                        </div>

                        <div class="promo-home">
                            <h3 class="promo-tit color-muta">bp <br class="d-none d-lg-block">innova</h3>
                            <div class="promo-desc promo-desc_azul color-muta"> <strong>proyectos</strong> de <br class="d-none d-lg-block">innovación digital <br class="d-none d-lg-block">y emprendimientos <br><a href="https://bpinnova.com" target="_blank" class="btn-conocelos">Conocelos acá</a></div>
                        </div>

                        <div>
                            <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" target="_blank" class="btn-common dark-mode" id="btn_abri_cuenta"><span>Abrí tu cuenta Patagonia Universitaria</span></a>
                            <a href="https://api.whatsapp.com/send/?phone=5491156350000&text=Hola!+%20&type=phone_number&app_absent=0" class="btn-padi-dark" target="_blank">¡Chateá con Padi 24/7!</a>
                        </div>
                    </div>
                </div>
            </div>

            <div id="lottie-chicx" class="lottie-overlay"></div>
            <script>
                const lottieChicx = lottie.loadAnimation({
                    container: document.getElementById('lottie-chicx'),
                    renderer: 'svg', // ('svg' o 'canvas')
                    loop: true,
                    autoplay: true,
                    path: 'lotties/Jovenes.json'
                });
            </script>
        </div>
    </section>

    <section class="section beneficios" id="beneficios">
        <video playsinline autoplay muted loop poster="image/poster-mobile-video.jpg">
            <source src="image/beneficios.mp4" type="video/webm">
			Tu navegador no soporta HTML5 video.
        </video>
        <div class="over-video"></div>
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-4">
                    <h2>Beneficios</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-lg-7">

                    <div class="">
                        <h3>Promo de bienvenida</h3>
                        <p>Te devolvemos el 50 % de tus compras con Tarjeta de Débito hasta alcanzar los $10.000</p>
                    </div>

                    <div class="ticket">
                        
                        <div class="ticket-content">
                            <div class="ticket-content-logo">
                                <!--<img src="image/icono_Regalo_Blanco.png" class="img-fluid">-->
								 <img src="image/icono_Regalo_Blanco.svg" class="img-fluid" />
                            </div>
                            <div class="ticket-content-info">
								<p class="">HASTA</p>
                                <h3>$ 10.000<br class="d-none d-md-block"> DE REGALO</h3>
                                <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminos">Ver más</a>
                            </div>
                        </div>

                        <div class="ticket-button ticket-btn_">
                            <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" target="_blank" class="btn-common">
                                <span class="d-md-flex">QUIERO SER PATAGONIA ON</span>
                                <!--<span class="d-none d-md-flex">QUIERO SER PATAGONIA ON</span>-->
                                <!--<span class="d-flex d-md-none">LO QUIERO</span>-->
							</a>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-lg-5">
                    <div class="bloque-mes">
                        <h3 class="mb-3">Beneficios destacados</h3>
                        <p class="d-none">Promociones en hamburguserías todos los días</p>
                        <ul class="promos-del-mes">
							
							<li>
                                <div class="marca-promo">
                                    <div class="logo-promo-mes"><img src="image/educacionit.png" class="img-fluid" />
                                    </div>
                                    <div class="name-promo-mes">Educación IT<br><span>Usando el cupón BENEFICIO_ON</span></div>
                                </div>
                                <div class="descuento">
                                    <div class="desc-promo-mes">50% <span>OFF</span></div>
                                    <div class="dia-promo-mes">Todos los dias</div>
                                </div>
                            </li>
							
                            <li>
                                <div class="marca-promo">
                                    <div class="logo-promo-mes"><img src="image/pedidosYa.png" class="img-fluid" />
                                    </div>
                                    <div class="name-promo-mes">Pedidos Ya<br><span>Tope $1.500 con Tarjeta de Débito</span></div>
                                </div>
                                <div class="descuento">
                                    <div class="desc-promo-mes">50% <span>OFF</span></div>
                                    <div class="dia-promo-mes">Todos los jueves</div>
                                </div>
                            </li>

                            <li>
                                <div class="marca-promo">
                                    <div class="logo-promo-mes "><img src="image/burger.png" class="img-fluid" /></div>
                                    <div class="name-promo-mes">Burger King<br><span>Tope $2.000 con Tarjeta de Débito</span></div>
                                </div>
                                <div class="descuento">
                                    <div class="desc-promo-mes ">50% <span>OFF</span></div>
                                    <div class="dia-promo-mes">Todos los viernes</div>
                                </div>
                            </li>

                            <li>
                                <div class="marca-promo">
                                    <div class="logo-promo-mes"><img src="image/havanna.png" class="img-fluid" /></div>
                                    <div class="name-promo-mes">Havanna<br><span>Tope $3.000 con Tarjeta de Crédito</span></div>
                                </div>
                                <div class="descuento">
                                    <div class="desc-promo-mes">30% <span>OFF</span></div>
                                    <div class="dia-promo-mes">Todos los martes</div>
                                </div>
                            </li>

                            <li>
                                <div class="marca-promo">
                                    <div class="logo-promo-mes"><img src="image/carrefour.png" class="img-fluid" />
                                    </div>
                                    <div class="name-promo-mes">Carrefour<br><span>Tope $3.000 con Tarjeta de Crédito<br> y Débito</span></div>
                                </div>
                                <div class="descuento">
                                    <div class="desc-promo-mes">15% <span>OFF</span></div>
                                    <div class="dia-promo-mes">Todos los miercoles</div>
                                </div>
                            </li>
							
							<!--
							<li>
                                <div class="marca-promo">
                                    <div class="logo-promo-mes"><img src="image/bares.png" class="img-fluid" />
                                    </div>
                                    <div class="name-promo-mes">Bares<br><span>Tope $3.000 con Tarjeta de Débito</span></div>
                                </div>
                                <div class="descuento">
                                    <div class="desc-promo-mes">30% <span>OFF</span></div>
                                    <div class="dia-promo-mes">16 y 17 DE MARZO</div>
                                </div>
                            </li>
							-->
							
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid ">
            <div class="row">
                <div class="col-12 pb-5">
                    <div class="postSlider">
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/cui.png" class="img-n" />
                                        <img src="image/sponsors/cui-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>15%</p>
                                                <h5>Sin tope</h5>
                                                <h5>Todos los dias</h5>
                                                <h6>Con el código PATAGONIA                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminoscui0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/educacionit.png" class="img-n" />
                                        <img src="image/sponsors/educacionit-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>50%</p>
                                                <h5>Todos los dias</h5>
                                                <h5>Con crédito y débito</h5>
                                                <h6>Sin tope                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminoseducacionit0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/pedidosYa.png" class="img-n" />
                                        <img src="image/sponsors/pedidosYa-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>50%</p>
                                                <h5>Los jueves</h5>
                                                <h5>Con débito</h5>
                                                <h6>Tope $1.500                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminospedidosya0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                    <div class="separador"></div>
                                                                                                                                            <p>30%</p>
                                                <h5>Los jueves</h5>
                                                <h5>Con crédito</h5>
                                                <h6>Tope $2.000                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminospedidosya1">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/burgerking.png" class="img-n" />
                                        <img src="image/sponsors/burgerking-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>50%</p>
                                                <h5>Los viernes</h5>
                                                <h5>Con débito</h5>
                                                <h6>Tope $2.000                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminosburgerking0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                    <div class="separador"></div>
                                                                                                                                            <p>30%</p>
                                                <h5>Los miércoles</h5>
                                                <h5>Con débito y crédito</h5>
                                                <h6>Tope $1.000                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminosburgerking1">Ver más</a>
                                                </h6>
                                                <h6>Exclusivo <img src="image/modo-blanco.png"></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/simones.png" class="img-n" />
                                        <img src="image/sponsors/simones-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>15% + 3 cuotas</p>
                                                <h5>Los jueves</h5>
                                                <h5>Con crédito y débito</h5>
                                                <h6>Tope $5.000                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminossimones0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/opensports.png" class="img-n" />
                                        <img src="image/sponsors/opensports-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>15%</p>
                                                <h5>Los jueves</h5>
                                                <h5>Con crédito</h5>
                                                <h6>Tope $5.000                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminosopensport0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/carrefour.png" class="img-n" />
                                        <img src="image/sponsors/carrefour-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>15%</p>
                                                <h5>Los miércoles</h5>
                                                <h5>Con crédito y débito</h5>
                                                <h6>Tope $3.000                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminoscarrefour0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/club-patagonia.png" class="img-n" />
                                        <img src="image/sponsors/club-patagonia-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>25%</p>
                                                <h5>Todos los días</h5>
                                                <h5>Con débito</h5>
                                                <h6>Tope $2.500                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminosclubpatagonia0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/icono_cine_blanco.png" class="img-n" />
                                        <img src="image/sponsors/icono_cine_h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>50%</p>
                                                <h5>Los viernes</h5>
                                                <h5>Con débito</h5>
                                                <h6>Tope $4.000                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminoscines0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/cabify.png" class="img-n" />
                                        <img src="image/sponsors/cabify-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>30%</p>
                                                <h5>Del 1/5 al 31/5</h5>
                                                <h5>Con crédito</h5>
                                                <h6>Tope $2.000 por viaje                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminoscabify0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/havanna.png" class="img-n" />
                                        <img src="image/sponsors/havanna-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>30%</p>
                                                <h5>Los martes</h5>
                                                <h5>Con crédito</h5>
                                                <h6>Tope $3.000                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminoshavanna0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/chelsea.png" class="img-n" />
                                        <img src="image/sponsors/chelsea-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>15%</p>
                                                <h5>Los jueves</h5>
                                                <h5>Con crédito y débito</h5>
                                                <h6>Tope $5.000                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminoschelsea0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/todo.png" class="img-n" />
                                        <img src="image/sponsors/todo-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>15%</p>
                                                <h5>Los martes</h5>
                                                <h5>Con crédito</h5>
                                                <h6>Tope $3.000                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminossupertodo0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/changomas.png" class="img-n" />
                                        <img src="image/sponsors/changomas-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>15%</p>
                                                <h5>Los viernes</h5>
                                                <h5>Con débito y crédito</h5>
                                                <h6>Tope $3.000                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminoschangomas0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                                        <div>
                                    <div class="sponsor-item">
                                        <img src="image/sponsors/cooperativa_obrera.png" class="img-n" />
                                        <img src="image/sponsors/cooperativa_obrera-h.png" class="img-h" />
                                        <div class="data">
                                                                                            <p>20%</p>
                                                <h5>Los jueves</h5>
                                                <h5>Con crédito</h5>
                                                <h6>Tope $4.000                                                    <a href="#" class="ver-terminos" data-bs-toggle="modal" data-bs-target="#modalTerminoscooperativaobrera0">Ver más</a>
                                                </h6>
                                                <h6></h6>
                                                                                                                                    </div>
                                    </div>
                                </div>
                                            </div>
                </div>
            </div>
        </div>
    </section>

    <section class="section club" id="club-patagonia">
        <div class="container">
            <div class="row">
                <div class="col-12 mb-5">
                    <h2>Club patagonia</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-6 d-flex d-lg-none">
                    <p id="info_club">Todas tus compras con tarjeta pueden sumar puntos para canjear por <strong>miles de productos, viajes, gift cards, descuentos, recargas y experiencias únicas.</strong><sup>(3)</sup></p>
                </div>
                <div class="col-6 col-lg-5">
                    <div class="tarjetas-animadas">
                        <div class="tarjeta-01"><img src="image/1-club-patagonia.png" class="img-fluid" /></div>
                        <div class="tarjeta-02"><img src="image/2-club-patagonia.png" class="img-fluid" /></div>
                        <div id="ani-strokes" class="ani-strokes"></div>

                        <script>
                            // Selecciona el contenedor donde se mostrará la animación
                            const animationContainer1 = document.getElementById('ani-strokes');

                            // Configura las opciones de la animación
                            const animationOptions1 = {
                                container: animationContainer1, // Contenedor HTML
                                renderer: 'svg', // Tipo de renderizador ('svg' o 'canvas')
                                loop: true, // Repetir la animación
                                autoplay: true, // Reproducir automáticamente la animación
                                path: 'lotties/Strokes2.json' // Ruta al archivo JSON de la animación
                            };

                            // Carga y reproduce la animación Lottie
                            const anim1 = lottie.loadAnimation(animationOptions1);
                        </script>
                    </div>
                </div>

                <div class="col-12 col-lg-7 mt-5 mt-lg-0">
                    <div class="bloque-club">
                        <p class="d-none d-lg-block">Todas tus compras con tarjeta pueden sumar puntos para canjear por <strong>miles de productos, viajes, gift cards, descuentos, recargas y experiencias únicas.</strong><sup>(3)</sup></p>

                        <ul class="list-club">
                            <li>
                                <img src="image/club-patagonia-1.png" class="img-fluid" />
                                <div class="club_caption">
                                    <p>Plata a favor en tus tarjetas</p>
                                </div>
                            </li>
                            <li>
                                <img src="image/club-patagonia-2.png" class="img-fluid" />
                                <div class="club_caption">
                                    <p>Carga tu Sube o celular</p>
                                </div>
                            </li>
                            <li>
                                <img src="image/club-patagonia-3.png" class="img-fluid" />
                                <div class="club_caption">
                                    <p>PedidosYa, supermercados y combustible</p>
                                </div>
                            </li>
                        </ul>
                        <div class="modulo-club">
                            <div>
                                <h3><strong>25% de <br class="d-none d-lg-block">DESCUENTO</strong></h3>
                                <p>Con tarjeta de Débito.<br>Tope $2.500</p>
                            </div>
                            <div class="plus">+</div>

                            <div class="mt-4">
                                <h3><strong>cuotas sin interés</strong></h3>
                                <p>Con tarjeta de Crédito</p>
                            </div>
                        </div>
                    </div>

                    <div class="text-center text-lg-end mt-3 mb-4 mb-lg-0 mt-lg-4">
                        <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" target="_blank" class="btn-common dark-mode" id="btn_abri_cuenta_club"><span>Abrí tu cuenta Patagonia On</span></a>
                    </div>

                </div>
            </div>
        </div>
        <div id="detalle_club_marcas">
            <img src="image/marcas-outline.png">
        </div>
    </section>

    <section class="section billetera pb-0" id="billetera">
        <div id="detalle_club_abajo">
            <img id="img_detalle_club_abajo" src="image/detalle-club.svg">
            <img id="img_detalle_club_abajo_dark" src="image/detalle-club-dark.svg">
        </div>
        <div class="container">
            <div class="row mb-5">
                <div class="col-12 ">
                    <h2 class="tit-billitera">Billetera</h2>
                    <h4 class="">Bajate Patagonia Móvil, vas a poder <strong>hacer de todo</strong></h4>
                </div>
            </div>

            <div class="row">
                <div class="col-12 col-lg-10 col-xxl-9">

                    <div class="bloque-billetera">
                        <div class="content">

                                                                <div class="capturas-mobile active" id="screen_paga">
                                        <div id="mobile_paga" class="fondo_animado" style="background-image: url('image/bg/como-quieras.gif');">
                                            <img src="image/mobile/paga-como-quieras.png">
                                        </div>
                                    </div>
                                                                <div class="capturas-mobile " id="screen_cuotas">
                                        <div id="mobile_cuotas" class="fondo_animado" style="background-image: url('image/bg/sin-tarjeta.gif');">
                                            <img src="image/mobile/cuotifica.png">
                                        </div>
                                    </div>
                                                                <div class="capturas-mobile " id="screen_envia">
                                        <div id="mobile_envia" class="fondo_animado" style="background-image: url('image/bg/sin-alias.gif');">
                                            <img src="image/mobile/envia-y-pedi-dinero-a-tus-contactos.png">
                                        </div>
                                    </div>
                                                                <div class="capturas-mobile " id="screen_ingresa">
                                        <div id="mobile_ingresa" class="fondo_animado" style="background-image: url('image/bg/ingresa-dinero.gif');">
                                            <img src="image/mobile/ingresa-dinero-de-otras-cuentas.png">
                                        </div>
                                    </div>
                                                                <div class="capturas-mobile " id="screen_recarga">
                                        <div id="mobile_recarga" class="fondo_animado" style="background-image: url('image/bg/recargas.gif');">
                                            <img src="image/mobile/recarga-tu-celu-y-tu-sube.png">
                                        </div>
                                    </div>
                                                                <div class="capturas-mobile " id="screen_inverti">
                                        <div id="mobile_inverti" class="fondo_animado" style="background-image: url('image/bg/inversiones.gif');">
                                            <img src="image/mobile/inverti-facil.png">
                                        </div>
                                    </div>
                            
                            <div class="list">
                                <div class="triggers_capturas">
                                    <ul>
                                                                                        <li class="current_trigger">
                                                    <button class="active" data-target="screen_paga">
                                                        <span>Pagá como quieras</span>
                                                    </button>
                                                </li>
                                                                                        <li class="">
                                                    <button class="" data-target="screen_cuotas">
                                                        <span>Cuotificá al toque</span>
                                                    </button>
                                                </li>
                                                                                        <li class="">
                                                    <button class="" data-target="screen_envia">
                                                        <span>Enviá y pedí dinero a tus contactos</span>
                                                    </button>
                                                </li>
                                                                                        <li class="">
                                                    <button class="" data-target="screen_ingresa">
                                                        <span>Ingresá dinero de otras cuentas</span>
                                                    </button>
                                                </li>
                                                                                        <li class="">
                                                    <button class="" data-target="screen_recarga">
                                                        <span>Recargá tu celu y tu SUBE</span>
                                                    </button>
                                                </li>
                                                                                        <li class="">
                                                    <button class="" data-target="screen_inverti">
                                                        <span>Invertí fácil</span>
                                                    </button>
                                                </li>
                                                                            </ul>
                                </div>

                                <div class="my-5 text-center d-block d-lg-none">
                                    <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" target="_blank" class="btn-common dark-mode w-100"><span>Abrí tu cuenta Patagonia On</span>
                                    </a>
                                </div>

                                <div class="patagonia-movil">
									<div id="patagonia_movil_logo">
										<img id="img_patagonia_movil_logo" class="mb-3" src="image/patagonia-movil.png">
										<img id="img_patagonia_movil_logo_dark" class="mb-3" src="image/patagonia-movil-white.png">
									</div>
									<!--
                                    <div><img src="image/patagonia-movil.png" class="mb-3"></div>
									
									<div id="detalle_club_abajo">
										<img id="img_detalle_club_abajo" src="image/detalle-club.svg">
										<img id="img_detalle_club_abajo_dark" src="image/detalle-club-dark.svg">
									</div>
									-->
                                    <ul>
                                        <li>
                                            <a href="https://apps.apple.com/ar/app/patagonia-m%C3%B3vil/id1178757002" target="_blank" class="">
                                                <img src="image/appStore.png" class="img-fluid">
                                            </a>
                                        </li>
                                        <li>
                                            <a href="https://play.google.com/store/apps/details?id=ar.com.bcopatagonia.android&hl=es_AR&gl=US" target="_blank" class="">
                                                <img src="image/playStore.png" class="img-fluid">
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="bloque-qr">
            <div class="qr">
                <p>Abrí tu cuenta<br> Patagonia ON</p>
                <img src="image/code_qr.png" class="img-fluid" id="qr_code" />
            </div>
            <img src="image/bg-qr.svg" class="img-fluid" />
        </div>
    </section>

    <section class="section inversiones" id="inversiones">
        <div id="lottie-inversiones" class="lottie-inversiones"></div>

        <script>
            // Selecciona el contenedor donde se mostrará la animación
            const animationContainer9 = document.getElementById('lottie-inversiones');

            // Configura las opciones de la animación
            const animationOptions9 = {
                container: animationContainer9, // Contenedor HTML
                renderer: 'svg', // Tipo de renderizador ('svg' o 'canvas')
                loop: true, // Repetir la animación
                autoplay: true, // Reproducir automáticamente la animación
                path: 'lotties/inversiones-clean.json' // Ruta al archivo JSON de la animación
            };

            // Carga y reproduce la animación Lottie
            const anim9 = lottie.loadAnimation(animationOptions9);
        </script>
        <div class="container">
            <div class="row">
                <div class="col-12 mb-5">
                    <h2>Inversiones</h2>
                    <h3>Hacé rendir tu plata <strong>fácil y rápido</strong><sup>(2)</sup></h3>
                </div>
            </div>

            <div class="row">
                <div class="col-12 col-lg-6">
                    <div class="oportunidad mb-5">
                        <h3 class="c-ico"><img src="image/fci.svg" class="img-fluid" />Fondo Común de Inversión</h3>
                        <h4>En 2 clicks podés poner a rendir tu plata a diario y hacer retiros totales o parciales en el
                            momento y cuando quieras.</h4>
                        <p>Opción para tus gastos diarios.</p>
                    </div>

                    <div class="oportunidad">
                        <h3 class="c-ico"><img src="image/plazo-fijo.svg" class="img-fluid" />Plazo Fijo</h3>
                        <h4>Poné a rendir tus ahorros y ganá intereses, es super fácil.</h4>
                                            </div>

                </div>

                <div class="col-12 col-lg-6">
                    <div class="tarjetas-animadas mt-3 d-none d-lg-flex">
                        <div class="tarjeta-01"><img src="image/card-fci.png" class="img-fluid" /></div>
                        <div class="tarjeta-02"><img src="image/card-plazo-fijo.png" class="img-fluid" /></div>
                    </div>
                </div>
            </div>

            <div class="row d-none d-lg-flex">
                <div class="col-12 mb-5 text-center">
                    <a href="https://tunuevacuenta.bancopatagonia.com.ar/onboarding/requirements/?c=6706&o=9781" target="_blank" class="btn-common dark-mode"><span>Abrí tu cuenta Patagonia On</span></a>
                </div>
            </div>
        </div>

        <div class="tarjetas-footer mt-3 d-flex d-lg-none">
            <img src="image/cards-mobile.png" alt="">
        </div>
    </section>
	<section class="section-legal" style="padding-bottom: 10px;">
		<div class="container">
            <div class="row">
                <div class="legal col-12">
					<p>(1) CARTERA DE CONSUMO – PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA DESDE EL 09/11/2023 HASTA EL 31/12/2024, AMBAS FECHAS INCLUIDAS, EXCLUSIVA PARA LOS PRODUCTOS CAJA DE AHORRO GRATUITA Y PATAGONIA ON.
					<br><br>
					EL OTORGAMIENTO DE LOS PRODUCTOS Y SERVICIOS DE BANCO PATAGONIA S.A. SE ENCUENTRA SUJETO A LA APROBACIÓN DE LAS CONDICIONES CREDITICIAS Y DE CONTRATACIÓN DE DICHA ENTIDAD.
					<br><br>
					PARA MÁS INFORMACIÓN ACERCATE A CUALQUIERA DE NUESTRAS SUCURSALES.
					<br><br>
					(2) LOS DEPÓSITOS EN PESOS Y EN MONEDA EXTRANJERA CUENTAN CON LA GARANTÍA DE HASTA $ 25.000.000. EN LAS OPERACIONES A NOMBRE DE DOS O MÁS PERSONAS, LA GARANTÍA SE PRORRATEARÁ ENTRE SUS TITULARES. EN NINGÚN CASO, EL TOTAL DE LA GARANTÍA POR PERSONA Y POR DEPÓSITO PODRÁ EXCEDER DE $ 25.000.000, CUALQUIERA SEA EL NÚMERO DE CUENTAS Y/O DEPÓSITOS. LEY 24.485, DECRETO Nº 540/95 Y MODIFICATORIOS Y COM. “A” 2337 Y SUS MODIFICATORIAS Y COMPLEMENTARIAS. SE ENCUENTRAN EXCLUIDOS LOS CAPTADOS A TASAS SUPERIORES A LA DE REFERENCIA CONFORME A LOS LÍMITES ESTABLECIDOS POR EL BANCO CENTRAL, LOS ADQUIRIDOS POR ENDOSO Y LOS EFECTUADOS POR PERSONAS VINCULADAS A LA ENTIDAD FINANCIERA.
					LAS INVERSIONES EN CUOTAS DEL FONDO NO CONSTITUYEN DEPÓSITOS EN BANCO PATAGONIA S.A. A LOS FINES DE LEY DE ENTIDADES FINANCIERAS NI CUENTAN CON NINGUNA DE LAS GARANTÍAS QUE TALES DEPÓSITOS A LA VISTA O A PLAZOS PUEDAN GOZAR DE ACUERDO CON LA LEGISLACIÓN Y REGLAMENTACIÓN APLICABLES EN MATERIA DE DEPÓSITOS EN ENTIDADES FINANCIERAS. ASIMISMO, BANCO PATAGONIA S.A. SE ENCUENTRA IMPEDIDO POR NORMAS DEL BANCO CENTRAL DE LA REPÚBLICA ARGENTINA DE ASUMIR, TÁCITA O EXPRESAMENTE, COMPROMISO ALGUNO EN CUANTO AL MANTENIMIENTO, EN CUALQUIER MOMENTO, DEL VALOR DEL CAPITAL INVERTIDO, AL RENDIMIENTO, AL VALOR DEL RESCATE DE LAS CUOTAS PARTES O AL OTORGAMIENTO DE LIQUIDEZ A TAL FIN, PATAGONIA INVERSORA SE ENCUENTRA REGISTRADO ANTE LA COMISION NACIONAL DE VALORES COMO AGENTE DE ADMINISTRACIÓN DE PRODUCTOS DE INVERSIÓN COLECTIVA DE FONDOS COMUNES DE INVERSIÓN BAJO EL Nº 14, POR SU PARTE, BANCO PATAGONIA S.A. SE ENCUENTRA REGISTRADO ANTE LA COMISIÓN NACIONAL DE VALORES COMO AGENTE DE CUSTODIA DE PRODUCTOS DE INVERSIÓN COLECTIVA DE FONDOS COMUNES DE INVERSIÓN BAJO EL Nº23.
					<br><br>
					(3) CONSULTÁ EL REGLAMENTO DE CLUB PATAGONIA EN http://WWW.BANCOPATAGONIA.COM.AR
					<br><br>
					LOS ACCIONISTAS DE BANCO PATAGONIA S.A. (CUIT: 30-50000661- 3, AV. DE MAYO 701 PISO 24 (C1084AAC), CIUDAD AUTÓNOMA DE BUENOS AIRES) LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA. LEY 25.738.
					<br><br>
					(4) CARTERA DE CONSUMO – PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA DESDE EL 01/05/2024 HASTA EL 30/09/2024, AMBAS FECHAS INCLUÍDAS, EXCLUSIVA PARA CLIENTES PERTENECIENTES AL SEGMENTO PATAGONIA ON. EL OTORGAMIENTO DEL PRÉSTAMO SE ENCUENTRA SUJETO A LA APROBACIÓN DE SUS CONDICIONES CREDITICIAS Y DE CONTRATACIÓN DISPUESTAS POR BANCO PATAGONIA S.A., LAS CUALES PODRÁN SER CONSULTADAS EN PATAGONIA Móvil ANTES DE SU ACEPTACIÓN, EN WWW. http://BANCOPATAGONIA.COM.AR Y EN CUALQUIERA DE NUESTRAS SUCURSALES. PARA COMPRAS ABONADAS EN CUOTAS POR USUARIOS DE SERVICIOS FINANCIEROS SE APLICARÁ: TASA NOMINAL ANUAL: 1% - TASA EFECTIVA ANUAL: 1% - COSTO FINANCIERO TOTAL EXPRESADO EN TASA EFECTIVA ANUAL (CFTNA).<br>
					<span style="font-size: 50px;">C.F.T.E.A. SIN IVA: (*) 1,00%</span><br>
					<span style="font-size: 50px;">C.F.T.E.A. CON IVA: (*) 1,22%</span><br>
					IMPORTE MÁXIMO A OTORGAR PARA PRÉSTAMOS SOLICITADOS POR PATAGONIA MÓVIL: HASTA $150.000 (PESOS CIENTO CINCUENTA MIL). LA ACREDITACIÓN DEL MONTO DEL PRÉSTAMO SE EFECTUARÁ EN SU CAJA DE AHORRO EN PESOS. EL CAPITAL DEBERÁ SER REEMBOLSADO EN CUOTAS MENSUALES Y CONSECUTIVAS. EL IMPORTE DE CADA CUOTA RESULTARÁ DE APLICAR EL “SISTEMA DE AMORTIZACIÓN FRANCÉS” DE INTERÉS SIMPLE E INCLUIRÁ LOS INTERESES COMPENSATORIOS A LA TASA PACTADA, EL I.V.A. Y LOS IMPUESTOS LOCALES QUE PUDIERAN CORRESPONDER DE ACUERDO A LA JURISDICCIÓN DEL CLIENTE.
					PARA UTILIZAR PATAGONIA MÓVIL DEBERÁ: (I) ENCONTRARSE PREVIAMENTE ADHERIDO A PATAGONIAEBANK; (II) POSEER UN TELÉFONO CELULAR CON SISTEMA OPERATIVO ANDROID O IOS (IPHONE) CON ACCESO A INTERNET Y SERVICIO DE DATOS; (III) ACEPTAR PREVIAMENTE SUS TÉRMINOS Y CONDICIONES, LOS CUALES PODRÁN SER CONSULTADOS EN http://WWW.BANCOPATAGONIA.COM.AR O EN CUALQUIERA DE NUESTRAS SUCURSALES.
					SIEMPRE DESCARGUE LA APLICACIÓN DE TIENDAS OFICIALES, NO ACCEDA DESDE LINKS QUE PROVENGAN DE MAILS O SMS. LOS COSTOS DE LA DESCARGA, DEL USO DE LA APLICACIÓN Y EL DE LA NAVEGACIÓN, SERÁN LOS QUE COBRE LA EMPRESA DE TELEFONÍA CELULAR UTILIZADA POR EL CLIENTE Y SERÁN A SU EXCLUSIVO CARGO. BANCO PATAGONIA S.A. NO SERÁ RESPONSABLE POR LOS ERRORES EN EL SOFTWARE DE LA APLICACIÓN, NI POR LA SUSPENSIÓN, INTERRUPCIÓN O FALLA DEL SERVICIO PROVENIENTE DE UNA MEDIDA UNILATERAL DE SU EMPRESA DE TELEFONÍA CELULAR.<br>
					Banco Patagonia nunca le solicitará que revele sus claves por ningún medio. Si recibe un e-mail o un llamado telefónico solicitándole sus claves personales, no lo responda. Nunca revele sus claves, datos personales o números de cuentas bancarias bajo ningún concepto. Ud. ha recibido este mensaje porque la empresa que lo remite considera que puede ser información de su interés.
					Ley 25.326, art. 27, inc. 3: El titular podrá en cualquier momento solicitar el retiro o bloqueo total a o parcial de su nombre de los bancos de datos a los que se refiere el presente artículo. Asimismo tiene la facultad de ejercer el derecho de acceso en forma gratuita a intervalos no inferiores a 6 meses. Art. 14 inc. 3) ley 25.326: lLa Dirección Nacional de Protección de Datos Personales tiene la atribución de atender denuncias y reclamos relativos al incumplimiento de normas sobre protección de datos personales. Banco Patagonia S.A. asume el carácter de Responsable Registrado ya que ha cumplimentado con todos los requisitos que exige esta ley.
					Los accionistas de Banco Patagonia S.A. (CUIT: 30-50000661- 3, Av. de Mayo 701 Piso 24 (C1084AAC), Ciudad Autónoma de Buenos Aires) limitan su responsabilidad a la integración de las acciones suscriptas. En virtud de ello, ni los accionistas mayoritarios de capital extranjero ni los accionistas locales o extranjeros, responden en exceso de la citada integración accionaria por las obligaciones emergentes de las operaciones concertadas por la entidad financiera. Ley 25.738.
					</p>
                </div>
				<div class="legal col-12">
					<p style="text-align: center;">© 2024 Banco Patagonia . Todos los derechos reservados. Prohibida la duplicación, distribución o almacenamiento en cualquier medio.</p>
                </div>
            </div>
		</div>
	
	</section>

                    <div class="modal fade" id="modalTerminoscui0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminoscui0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminoscui0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA, DESDE EL 12/04/2024 HASTA EL 31/12/2024, AMBAS FECHAS INCLUÍDAS, PARA COMPRAS REALIZADAS EN HTTPS://CUI.EDU.AR/, ABONADAS EXCLUSIVAMENTE CON LAS TARJETAS DE DÉBITO PATAGONIA 24 Y LAS TARJETAS DE CRÉDITO MASTERCARD DEL SEGMENTO PATAGONIA ON, EMITIDAS POR BANCO PATAGONIA S.A. NO ACUMULABLE CON OTRAS PROMOCIONES Y/O BENEFICIOS VIGENTES. EL BENEFICIO CONSISTE EN LA BONIFICACIÓN DEL 15% (QUINCE POR CIENTO) - SIN TOPE DE REINTEGRO - DEL PRECIO CORPORATIVO DENOMINADO PRECIO CORPORATE PARA CURSOS GRUPALES, ZOOM Y PRESENCIALES, CUATRIMESTRALES, BIMESTRALES Y TRIMESTRABLES EN LOS 24 IDIOMAS. Y PLATAFORMAS ASINCRÓNICAS DE IDIOMAS: INGLÉS -ITALIANO – ALEMÁN – FRANCES – LENGUAJE DE SEÑAS ARGENTINA CON IA. PARA ACCEDER AL BENEFICIO, DEBERÁ CONTAR CON UNA CUENTA ABIERTA Y ACTIVA EN BANCO PATAGONIA S.A. Y APLICAR - PREVIO AL PAGO - EL CUPÓN “PATAGONIA”. DICHO  CUPÓN ES VÁLIDO POR ÚNICA VEZ DURANTE LA VIGENCIA DE LA PRESENTE PROMOCIÓN, NO ES INTERCAMBIABLE POR DINERO EN EFECTIVO Y NO APLICA PARA CARRERAS, MÓDULOS, BOOTCAMPS NI VOUCHERS PARA CERTIFICACIÓN. EL DESCUENTO LO VERÁ REFLEJADO EN EL CARRITO DE COMPRAS DE CUI, QUIEN SERÁ EL ÚNICO RESPONSABLE POR LA PRESTACIÓN, CORRECTO FUNCIONAMIENTO Y/O GARANTÍA DEL PRODUCTO Y/O SERVICIO ADQUIRIDO. CUALQUIER RECLAMO DEBERÁ DIRIGIRLO CONTRA DICHA EMPRESA. LOS ACCIONISTAS DE BANCO PATAGONIA S.A. (CUIT: 30-50000661- 3, AV. DE MAYO 701 PISO 24 (C1084AAC), CIUDAD AUTÓNOMA DE BUENOS AIRES) LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA. LEY 25.738.</p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminoseducacionit0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminoseducacionit0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminoseducacionit0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA, DESDE EL 12/04/2024 HASTA EL 31/12/2024, AMBAS FECHAS INCLUÍDAS, PARA COMPRAS REALIZADAS EN WWW.EDUCACIONIT.COM, ABONADAS EXCLUSIVAMENTE CON LAS TARJETAS DE DÉBITO PATAGONIA24 Y LAS TARJETAS DE CRÉDITO MASTERCARD DEL SEGMENTO PATAGONIA ON, EMITIDAS POR BANCO PATAGONIA S.A. NO ACUMULABLE CON OTRAS PROMOCIONES Y/O BENEFICIOS VIGENTES. EL BENEFICIO CONSISTE EN LA BONIFICACIÓN DEL 50% (CINCUENTA POR CIENTO) - SIN TOPE DE REINTEGRO - DEL PRECIO DE LISTA DE LAS INSCRIPCIONES A LOS CURSOS PUBLICADOS Y ABIERTOS CON FECHAS DISPONIBLES, COMO ASÍ TAMBIÉN PARA LOS SIMULADORES DE EXÁMENES, REALIZADAS EN LA WEB MENCIONADA PREVIAMENTE, PARA ACCEDER AL BENEFICIO, DEBERÁ CONTAR CON UNA CUENTA ABIERTA Y ACTIVA EN BANCO PATAGONIA S.A. Y APLICAR - PREVIO AL PAGO - EL CUPÓN “BENEFICIO_ON”. DICHO CUPÓN ES VÁLIDO POR ÚNICA VEZ DURANTE LA VIGENCIA DE LA PRESENTE PROMOCIÓN, NO ES INTERCAMBIABLE POR DINERO EN EFECTIVO Y NO APLICA PARA CARRERAS, MÓDULOS, BOOTCAMPS NI VOUCHERS PARA CERTIFICACIÓN. EL DESCUENTO LO VERÁ REFLEJADO EN EL CARRITO DE COMPRAS DE EDUCACIÓN IT, QUIEN SERÁ EL ÚNICO RESPONSABLE POR LA PRESTACIÓN, CORRECTO FUNCIONAMIENTO Y/O GARANTÍA DEL PRODUCTO Y/O SERVICIO ADQUIRIDO. CUALQUIER RECLAMO DEBERÁ DIRIGIRLO CONTRA DICHA EMPRESA. LOS ACCIONISTAS DE BANCO PATAGONIA S.A. (CUIT: 30-50000661- 3, AV. DE MAYO 701 PISO 24 (C1084AAC), CIUDAD AUTÓNOMA DE BUENOS AIRES) LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA. LEY 25.738.</p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminospedidosya0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminospedidosya0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminospedidosya0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA EXCLUSIVAMENTE LOS JUEVES, DESDE EL 01/01/2024 HASTA EL 31/03/2024, AMBAS FECHAS INCLUIDAS, PARA COMPRAS EFECTUADAS CON LA TARJETA DE DÉBITO PATAGONIA 24 EMITIDAS POR BANCO PATAGONIA SA RECIBIRA UN 50% DE DESCUENTO EN PEDIDOS YA. TOPE DE REINTEGTRO POR MES: $1500. NO ACUMULABLE CON OTRAS PROMOCIONES. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO.</p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminospedidosya1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminospedidosya1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminospedidosya1">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA EXCLUSIVAMENTE LOS JUEVES, DESDE EL 01/01/2024 HASTA EL 31/03/2024, AMBAS FECHAS INCLUIDAS, PARA COMPRAS EFECTUADAS CON LA TARJETA DE CREDITO MASTERCARD EMITIDAS POR BANCO PATAGONIA SA. RECIBIRA UN 30% DE DESCUENTO EN 1 PAGO EN PEDIDOS YA. TOPE DE REINTEGTRO POR MES Y POR CUENTA: $2000: LOS REINTEGROS CORRESPONDIENTES A LAS COMPRAS EFECTUADAS CON LAS TARJETA DE CRÉDITO MASTERCARD EMITIDAS POR BANCO PATAGONIA. SE VISUALIZARÁN EN EL PRIMER RESUMEN O EN EL INMEDIATO POSTERIOR.</p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminosburgerking0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminosburgerking0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminosburgerking0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA EXCLUSIVAMENTE LOS VIERNES, DESDE EL 01/01/2024 HASTA EL 31/03/2024, AMBAS FECHAS INCLUIDAS, PARA COMPRAS EFECTUADAS CON LA TARJETA DE DÉBITO PATAGONIA 24 EMITIDAS POR BANCO PATAGONIA SA RECIBIRA UN 50% DE DESCUENTO EN BURGUER KING.  TOPE DE REINTEGTRO POR MES: $2000:   NO ACUMULABLE CON OTRAS PROMOCIONES.  EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO. </p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminosburgerking1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminosburgerking1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminosburgerking1">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA EXCLUSIVAMENTE LOS VIERNES, DESDE EL 01/01/2024 HASTA EL 31/03/2024, AMBAS FECHAS INCLUIDAS, PARA COMPRAS EFECTUADAS CON LA TARJETA DE DÉBITO PATAGONIA 24 EMITIDAS POR BANCO PATAGONIA SA RECIBIRA UN 50% DE DESCUENTO EN BURGUER KING.  TOPE DE REINTEGTRO POR MES: $2000:   NO ACUMULABLE CON OTRAS PROMOCIONES.  EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO. </p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminossimones0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminossimones0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminossimones0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>BONIFICACIONES VIGENTES, EN EL PAÍS, HASTA 30/06/2024. ABONANDO LOS JUEVES CON TODAS LAS TARJETAS DE CRÉDITO MASTERCARD DEL SEGMENTO PATAGONIA ON Y DÉBITO PATAGONIA 24 DE BANCO PATAGONIA, RECIBIRÁ UN DESCUENTO DEL 15% Y FINANCIACIÓN EN HASTA TRES CUOTAS SIN INTERÉS EN LOS LOCALES ADHERIDOS DE SIMONES. TOPE: $5000 POR CUENTA Y POR MES. EL IMPORTE BONIFICADO POR LAS COMPRAS EN UN PAGO O EN CUOTAS REALIZADAS CON TARJETA MASTERCARD DE BANCO PATAGONIA, SERÁ ACREDITADO EN EL MISMO RESUMEN EN QUE INGRESE EL CONSUMO (O PRIMERA CUOTA) O BIEN EN EL INMEDIATO POSTERIOR. EN EL CASO DE COMPRAS CON TARJETAS DE DÉBITO LAS BONIFICACIONES SE ACREDITARÁN EN LA CUENTA DE DÉBITO, DENTRO DE LOS 10 DÍAS HÁBILES DE REALIZADA LA COMPRA. SE EXCLUYEN TARJETAS CORPORATIVAS. PROMOCIÓN NO ACUMULABLE CON OTRAS PROMOCIONES. LAS CUENTAS NO DEBERÁN REGISTRAR MORA. BANCO PATAGONIA S.A. NO SE RESPONSABILIZA POR LOS CUPONES PRESENTADOS FUERA DE LA FECHA DE VIGENCIA DE LA PROMOCIÓN. (*) PARA COMPRAS ABONADAS EN CUOTAS POR USUARIOS DE SERVICIOS FINANCIEROS - CARTERA DE CONSUMO - SE APLICARÁ: TASA NOMIN AL ANUAL: 0% - TASA EFECTIVA ANUAL: 0% - COSTO SEGURO DE VIDA 0% - COSTO FINANCIERO TOTAL (C.F.T.) EXPRESADO EN TASA EFECTIVA. (**) PARA COMPRAS ABONADAS EN CUOTAS POR CLIENTES DE CARTERA COMERCIAL, SE APLICARÁ: TASA NOMINAL ANUAL: 0% - TASA EFECTIVA ANUAL: 0% - COSTO SEGURO DE VIDA 0.35% - COSTO FINANCIERO TOTAL. ESTA PROMOCIÓN SE AJUSTA A LA RESOLUCIÓN 51 E/2017 DE LA SECRETARÍA DE COMERCIO SIENDO LAS CUOTAS SIN INTERÉS. COSTO FINANCIERO TOTAL. PROMOCIONES CONFORME RESOLUCIÓN 51 E/2017 DE LA SECRETARÍA DE COMERCIO.</p>
				<p>C.F.T.N.A. (con y sin IVA): (*) 0,00% (**) 4,34%</p>
				<p>EL BENEFICIO NO APLICA PARA AQUELLOS PAGOS Y/O CONSUMOS ABONADOS CON TARJETAS DE DÉBITO Y CRÉDITO EMITIDAS POR BANCO PATAGONIA S.A. A TRAVÉS DE BILLETERAS VIRTUALES, POS MÓVILES, PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE.</p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminosopensport0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminosopensport0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminosopensport0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA EXCLUSIVAMENTE LOS JUEVES, DESDE EL 29/03/2024 HASTA EL 30/06/2024, AMBAS FECHAS INCLUIDAS, PARA COMPRAS EFECTUADAS CON LA TARJETA DE CRÉDITO MASTERCARD DEL SEGMENTO PATAGONIA ON EMITIDAS POR BANCO PATAGONIA SA. RECIBIRA UN 15% DE DESCUENTO EN LOS COMERCIOS ADHERIDOS DE OPEN SPORT. TOPE DE REINTEGTRO POR MES: $5000: NO ACUMULABLE CON OTRAS PROMOCIONES. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO.</p>            
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminoscarrefour0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminoscarrefour0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminoscarrefour0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA EXCLUSIVAMENTE LOS MIERCOLES DESDE EL 06/05/2024 HASTA EL 31/07/2024, AMBAS FECHAS INCLUIDAS, PARA COMPRAS EFECTUADAS CON LA TARJETA DE DÉBITO PATAGONIA 24 EMITIDAS POR BANCO PATAGONIA SA. RECIBIRA UN 15% DE DESCUENTO EN LOS LOCALES HIPERMERCADOS CARREFOUR, CARREFOUR MARKET, CARREFOUR EXPRESS. TOPE DE REINTEGTRO POR MES: $3.000: S.A. NO ACUMULABLE CON OTRAS PROMOCIONES. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO. SE EXCLUYE, ELECTRÓNICA, ELECTRODOMÉSTICOS Y TELEFONÍA CELULAR. SE EXCLUYEN ADICIONALES DE TARJETA DE DÉBITO. PROMOCIÓN NO ACUMULABLE CON OTRAS PROMOCIONES. TOPE DE DEVOLUCIÓN $3.000 POR MES Y POR CUENTA. NO PARTICIPA CARREFOUR MAXI. NO INCLUYE MOTOS, CUATRICICLOS, BICICLETAS MOTORIZADAS, TRACTORES, BODEGAS CHANDON, LEONCIO ARIZU, TERRAZAS DE LOS ANDES, TRUMPETER, LA RURAL, RUTINI WINES, LATITUD 33, CLOS DE LOS SIETE, CATENA ZAPATA, NI PRODUCTOS DE CONVENIO DE PRECIOS CUIDADOS, LECHES INFANTILES Y MATERNIZADAS ETAPA 1 Y 2 NI CARNICERÍA: CARNE VACUNA, POLLO, CORTES DE CERDOS Y EMBUTIDOS. NO INCLUYE PRODUCTOS DE LA MARCA CARREFOUR DE ALIMENTOS, LÁCTEOS, QUESOS, FIAMBRES, BEBIDAS, PERFUMERÍA Y LIMPIEZA. NO ACUMULABLE CON OTRAS PROMOCIONES VIGENTES.</p>                
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminosclubpatagonia0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminosclubpatagonia0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminosclubpatagonia0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA TODOS LOS DIAS, DESDE EL 01/01/2024 HASTA EL 31/03/2024, AMBAS FECHAS INCLUIDAS, PARA COMPRAS EFECTUADAS CON LA TARJETA DE DÉBITO PATAGONIA 24 EMITIDAS POR BANCO PATAGONIA SA.   RECIBIRA UN 25% DE DESCUENTO EN LOS COMERCIOS ADHERIDOS DE CLUB PATAGONIA.  TOPE DE REINTEGTRO POR MES: $2500: NO ACUMULABLE CON OTRAS PROMOCIONES. PARA MÁS INFORMACIÓN CONSULTE EL REGLAMENTO DE CLUB PATAGONIA EN WWW.CLUBPATAGONIA.COM.AR O ACERQUESE A CUALQUIERA DE NUESTRAS SUCURSALES</p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminoscines0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminoscines0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminoscines0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA EXCLUSIVAMENTE LOS VIERNES, DESDE EL 03/04/2024 HASTA EL 31/07/2024, AMBAS FECHAS INCLUIDAS, PARA COMPRAS EFECTUADAS CON LA TARJETA DE DÉBITO PATAGONIA 24 EMITIDAS POR BANCO PATAGONIA SA. RECIBIRA UN 50% DE DESCUENTO EN LOS COMERCIOS REGISTRADOS BAJO EL RUBRO CINES. TOPE DE REINTEGTRO POR MES: $4.000: S.A. NO ACUMULABLE CON OTRAS PROMOCIONES. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE PLATAFORMAS ON LINE, BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO.</p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminoscabify0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminoscabify0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminoscabify0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>TODOS LOS DÍAS, SUS CLIENTES DE TARJETAS MASTERCARD DÉBITO, CRÉDITO Y PREPAGO PODRÁN CONTAR CON UN 30% DE DESCUENTO EN VIAJES Y ENVÍOS DE CABIFY INGRESANDO EL CUPÓN “MASTERMAY”.</p>
				<p>VÁLIDO EN 2 VIAJES POR MES Y POR USUARIO CON UN TOPE DE $2.000 POR VIAJE. PROMOCIÓN EXCLUSIVA PARA USUARIOS REGISTRADOS Y VÁLIDA PARA VIAJES Y ENVÍOS REALIZADOS EN LA ZONA METROPOLITANA DE BUENOS AIRES, CÓRDOBA, MENDOZA, ROSARIO Y CORRIENTES. HASTA AGOTAR STOCK DE 20.000 CLAIMS.</p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminoshavanna0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminoshavanna0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminoshavanna0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA EXCLUSIVAMENTE LOS MARTES, DESDE EL 05/04/2024 HASTA EL 30/06/2024, AMBAS FECHAS INCLUIDAS, PARA COMPRAS EFECTUADAS CON LA TARJETA DE CREDITO MASTERCARD EMITIDAS POR BANCO PATAGONIA SA. RECIBIRA UN 30% DE DESCUENTO EN 1 PAGO EN LOS COMERCIOS ADHERIDOS DE HAVANNA. TOPE DE REINTEGTRO POR MES Y POR CUENTA: $3.000: LOS REINTEGROS CORRESPONDIENTES A LAS COMPRAS EFECTUADAS CON LAS TARJETA DE CRÉDITO MASTERCARD EMITIDAS POR BANCO PATAGONIA. SE VISUALIZARÁN EN EL PRIMER CONSUMO O EN EL INMEDIATO POSTERIOR</p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminoschelsea0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminoschelsea0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminoschelsea0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA EXCLUSIVAMENTE LOS JUEVES, DESDE EL 10/04/2024 HASTA EL 30/06/2024, AMBAS FECHAS INCLUIDAS, PARA COMPRAS EFECTUADAS CON LA TARJETA DE CREDITO MASTERCARD Y TARJETA DE DÉBITO PATAGONIA 24 EMITIDAS POR BANCO PATAGONIA SA. RECIBIRA UN 15% DE DESCUENTO EN 1 PAGO EN LOS COMERCIOS ADHERIDOS DE CHELSEA. TOPE DE REINTEGTRO POR MES Y POR CUENTA: $5.000.</p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminossupertodo0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminossupertodo0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminossupertodo0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA EXCLUSIVAMENTE LOS MARTES DESDE EL 06/05/2024 HASTA EL 31/07/2024, AMBAS FECHAS INCLUIDAS, PARA COMPRAS EFECTUADAS CON LA TARJETA DE DÉBITO PATAGONIA 24 Y LAS TARJETAS DE CRÉDITO MASTERCARD EMITIDAS POR BANCO PATAGONIA SA. RECIBIRA UN 15% DE DESCUENTO EN LOS LOCALES DE SUPERMERCADOS TODO. TOPE DE REINTEGRO POR MES: $3.000: S.A. NO ACUMULABLE CON OTRAS PROMOCIONES. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO. SE EXCLUYE, ELECTRÓNICA, ELECTRODOMÉSTICOS Y TELEFONÍA CELULAR. NO ACUMULABLE CON OTRAS PROMOCIONES VIGENTES.</p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminoschangomas0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminoschangomas0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminoschangomas0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA EXCLUSIVAMENTE LOS VIERNES DESDE EL 06/05/2024 HASTA EL 31/07/2024, AMBAS FECHAS INCLUIDAS, PARA COMPRAS EFECTUADAS CON LA TARJETA DE DÉBITO PATAGONIA 24 Y LAS TARJETAS DE CRÉDITO EMITIDAS POR BANCO PATAGONIA SA. RECIBIRA UN 15% DE DESCUENTO EN LOS LOCALES DE CHANGOMAS. TOPE DE REINTEGRO POR MES: $3.000: S.A. NO ACUMULABLE CON OTRAS PROMOCIONES. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO. SE EXCLUYE, ELECTRÓNICA, ELECTRODOMÉSTICOS Y TELEFONÍA CELULAR. NO ACUMULABLE CON OTRAS PROMOCIONES VIGENTES.</p>
				<p>EL IMPORTE BONIFICADO POR LAS COMPRAS ABONADAS CON LA TARJETA PATAGONIA24 SE ACRÉDITARÁ EN LA CUENTA DEL CLIENTE DENTRO DE LOS 10 DÍAS DE REALIZADO/S EL/LOS CONSUMO/S. LOS REINTEGROS CORRESPONDIENTES A LAS COMPRAS EFECTUADAS CON LAS TARJETAS DE CRÉDITO VISA, MASTERCARD Y AMERICAN EXPRESS DEL BANCO- SE VISUALIZARÁN EN EL RESUMEN EN QUE INGRESE LA PRIMERA CUOTA Y/O EN EL INMEDIATO POSTERIOR. LAS CUENTAS NO DEBERÁN REGISTRAR MORA. BANCO PATAGONIA S.A. NO SE RESPONSABILIZA POR LOS CUPONES PRESENTADOS FUERA DE LA FECHA DE VIGENCIA DE LA PROMOCIÓN. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO. LOS ACCIONISTAS DE BANCO PATAGONIA S.A. (CUIT: 30-50000661-3, AV. DE MAYO 701 PISO 24 (C1084AAC), CIUDAD AUTÓNOMA DE BUENOS AIRES) LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA (LEY 25.738).</p>
                                            </div>
                        </div>
                    </div>
                </div>
                    <div class="modal fade" id="modalTerminoscooperativaobrera0" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                    aria-labelledby="modalTerminoscooperativaobrera0" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h3 class="modal-title" id="modalTerminoscooperativaobrera0">Términos y condiciones</h3>
                                <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body modal_body_terminos">
                                <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA EXCLUSIVAMENTE LOS JUEVES DESDE EL 06/05/2024 HASTA EL 31/07/2024, AMBAS FECHAS INCLUIDAS, PARA COMPRAS EFECTUADAS CON LA TARJETA DE DÉBITO PATAGONIA 24 Y LAS TARJETAS DE CRÉDITO MASTERCARD EMITIDAS POR BANCO PATAGONIA SA. RECIBIRA UN 20% DE DESCUENTO EN LOS LOCALES DE LA COPPERATIVA OBRERA. TOPE DE REINTEGRO POR MES: $4.000: S.A. NO ACUMULABLE CON OTRAS PROMOCIONES. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO. SE EXCLUYE, ELECTRÓNICA, ELECTRODOMÉSTICOS Y TELEFONÍA CELULAR. NO ACUMULABLE CON OTRAS PROMOCIONES VIGENTES.</p>
				<p>EL IMPORTE BONIFICADO POR LAS COMPRAS ABONADAS CON LA TARJETA PATAGONIA24 SE ACRÉDITARÁ EN LA CUENTA DEL CLIENTE DENTRO DE LOS 10 DÍAS DE REALIZADO/S EL/LOS CONSUMO/S. LOS REINTEGROS CORRESPONDIENTES A LAS COMPRAS EFECTUADAS CON LAS TARJETAS DE CRÉDITO MASTERCARD DEL BANCO- SE VISUALIZARÁN EN EL RESUMEN EN QUE INGRESE LA PRIMERA CUOTA Y/O EN EL INMEDIATO POSTERIOR. LAS CUENTAS NO DEBERÁN REGISTRAR MORA. BANCO PATAGONIA S.A. NO SE RESPONSABILIZA POR LOS CUPONES PRESENTADOS FUERA DE LA FECHA DE VIGENCIA DE LA PROMOCIÓN. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO. LOS ACCIONISTAS DE BANCO PATAGONIA S.A. (CUIT: 30-50000661-3, AV. DE MAYO 701 PISO 24 (C1084AAC), CIUDAD AUTÓNOMA DE BUENOS AIRES) LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA (LEY 25.738).</p>
                                            </div>
                        </div>
                    </div>
                </div>
    

    <!-- Vertically centered scrollable modal -->
    <div class="modal fade" id="modalTerminos" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="modalTerminos" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="modalTerminos">Términos y condiciones Beneficio de bienvenida</h3>
                    <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body modal_body_terminos">
                    <p>CARTERA DE CONSUMO - PROMOCIÓN VÁLIDA EN LA REPÚBLICA ARGENTINA DESDE EL 08/04/2024 HASTA EL 31/08/2024, AMBAS FECHAS INCLUIDAS, EXCLUSIVA PARA EL DESTINATARIO DE LA PRESENTE PIEZA. NO ACUMULABLE CON OTRAS PROMOCIONES. EL BENEFICIO CONSISTE EN LA BONIFICACIÓN DEL 50% DE CUALQUIER CONSUMO EFECTUADO/S CON LA TARJETA DE DÉBITO PATAGONIA24 EMITIDA POR BANCO PATAGONIA S.A, EN COMERCIOS DE ARGENTINA DENTRO DE LOS 30 (TREINTA) DÍAS DE LA FECHA DEL ALTA DE DICHA TARJETA, HASTA ALCANZAR UN TOPE TOTAL DE REINTEGRO DE $10.000 (PESOS DIEZ MIL). EL IMPORTE BONIFICADO POR LAS COMPRAS ABONADAS CON LA TARJETA PATAGONIA24 SE ACRÉDITARÁ EN LA CUENTA DEL CLIENTE DENTRO DE LOS 30 DÍAS DE REALIZADO/S EL/LOS CONSUMO/S. LAS CUENTAS NO DEBERÁN REGISTRAR MORA. BANCO PATAGONIA S.A. NO SE RESPONSABILIZA POR LOS CUPONES PRESENTADOS FUERA DE LA FECHA DE VIGENCIA DE LA PROMOCIÓN. EL BENEFICIO NO APLICA PARA PAGOS EFECTUADOS A TRAVÉS DE BILLETERAS VIRTUALES NI EN COMERCIOS QUE COBREN CON POST MÓVILES/POSTNET DE PLATAFORMAS DE PAGO Y/O PORTALES DE PAGO ON LINE A EXCEPCION DE MODO. LOS ACCIONISTAS DE BANCO PATAGONIA S.A. (CUIT: 30-50000661-3, AV. DE MAYO 701 PISO 24 (C1084AAC), CIUDAD AUTÓNOMA DE BUENOS AIRES) LIMITAN SU RESPONSABILIDAD A LA INTEGRACIÓN DE LAS ACCIONES SUSCRIPTAS. EN VIRTUD DE ELLO, NI LOS ACCIONISTAS MAYORITARIOS DE CAPITAL EXTRANJERO NI LOS ACCIONISTAS LOCALES O EXTRANJEROS, RESPONDEN EN EXCESO DE LA CITADA INTEGRACIÓN ACCIONARIA POR LAS OBLIGACIONES EMERGENTES DE LAS OPERACIONES CONCERTADAS POR LA ENTIDAD FINANCIERA (LEY 25.738).</p>
                </div>
            </div>

        </div>
    </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="modalUniversidades" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="modalUniversidades" aria-hidden="true">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="modalUniversidades">Espacios Exclusivos</h3>
                    <button type="button" class="btn-close modal-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 col-lg-6">

                                <ul class="list-uni">
                                    <li>
                                        <h4>Centro Universitario Parque Gral. San Mart&iacute;n</h4>
                                    </li>
                                    <li>
                                        <h4>Universidad de Cuyo</h4>
                                        <p>(Sede San Rafael - Facultad de Ciencias Aplicadas a la Industria)</p>
                                        <p>Bernardo de Irigoyen 375 - San Rafael Mendoza</p>
                                    </li>
                                    <li>
                                        <h4>Universidad de la Rioja</h4>
                                        <p>Laprida y Vte. Bustos</p>
                                        <p>La Rioja</p>
                                    </li>
                                    <li>
                                        <h4>Universidad de Lomas de Zamora</h4>
                                        <p>Camino de Cintura y Av. Juan XXIII</p>
                                        <p>Lomas de Zamora</p>
                                    </li>
                                    <li>
                                        <h4>Universidad de Salta</h4>
                                        <p>Av. Bolivia 5154</p>
                                        <p>Salta</p>
                                    </li>
                                    <li>
                                        <h4>Universidad del Nordeste (Cs. Econ&oacute;micas)</h4>
                                        <p>Sede Resistencia - Av. Las Heras 727</p>
                                        <p>Resistencia Chaco</p>
                                    </li>
                                    <li>
                                        <h4>Universidad del Nordeste (Cs. Veterinarias)</h4>
                                        <p>Sede Corrientes Sgto. Cabral 2139</p>
                                        <p>Corrientes</p>
                                    </li>
                                    <li>
                                        <h4>Universidad del Nordeste (Odontolog&iacute;a)</h4>
                                        <p>Sede Corrientes - Av. Libertad 5450 - Ctro. De atenci&oacute;n Comercial
                                            Deodoro Roca</p>
                                        <p>Corrientes</p>
                                    </li>
                                </ul>

                            </div>
                            <div class="col-12 col-lg-6">

                                <ul class="list-uni">

                                    <li>
                                        <h4>Universidad del Sur 1</h4>
                                        <p>Rectorado - Col&oacute;n 80</p>
                                        <p>Bahia Blanca</p>
                                    </li>
                                    <li>
                                        <h4>Universidad del Sur 2</h4>
                                        <p>Escuelas Medias - 11 de Abril 445</p>
                                        <p>Bahia Blanca</p>
                                    </li>
                                    <li>
                                        <h4>Universidad del Sur 3</h4>
                                        <p>Alem - Alem 1253</p>
                                        <p>Bahia Blanca</p>
                                    </li>
                                    <li>
                                        <h4>Universidad del Sur 4</h4>
                                        <p>Altos del Palihue - San Andr&eacute;s 800</p>
                                        <p>Bahia Blanca</p>
                                    </li>
                                    <li>
                                        <h4>Universidad Maimonides</h4>
                                        <p>Hidalgo 775</p>
                                        <p>Caballito</p>
                                    </li>
                                    <li>
                                        <h4>Universidad Nacional de San Martin</h4>
                                        <p>Av. 25 de Mayo 1405</p>
                                        <p>San Martin</p>
                                    </li>
                                    <li>
                                        <h4>Universidad Nacional de Villa Maria</h4>
                                        <p>Av Arturo Jaureche 1555</p>
                                        <p>Villa Maria C&oacute;rdoba</p>
                                    </li>
                                    <li>
                                        <h4>UTN</h4>
                                        <p>Mozar 2300</p>
                                        <p>Villa Lugano</p>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- partial -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js" integrity="sha512-XtmMtDEcNz2j7ekrtHvOVR4iwwaD6o/FUJe6+Zq+HgcCsk3kj4uSQQR8weQ2QVj1o0Pk6PwYLohm206ZzNfubg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/swiped-events/1.1.7/swiped-events.min.js" integrity="sha512-q2rGCiN6EL2X7aJwVzSD6E0GbpfcGSjipdpZ12lqArQfSMb/LTDXlSFZLrohrSanuRk2/oP96lb14NNgPCAZPw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script type="text/javascript" src="js/main.js?v=20240607235626"></script>
</body>

</html>